def classFactory(iface):
    try:
        import pystac_client
    except ImportError:
        raise ImportError(
            "Este plugin requer o plugin 'STAC API Browser' "
            "ou o pacote 'pystac-client' instalado no Python do QGIS."
        )

    from .main_plugin import BDC_INPE_Sentinel2_Plugin
    return BDC_INPE_Sentinel2_Plugin(iface)


