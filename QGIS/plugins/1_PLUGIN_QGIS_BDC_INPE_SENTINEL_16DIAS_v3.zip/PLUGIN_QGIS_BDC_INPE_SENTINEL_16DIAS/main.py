from qgis.PyQt import QtWidgets
from qgis.core import QgsRasterLayer, QgsProject
from osgeo import gdal
import os
import re
import numpy as np
import requests
from io import BytesIO
from PyQt5.QtWidgets import QApplication, QTabWidget
from datetime import datetime, timedelta



#-------------------------------GERAÇÃO DA INTERFACE------------------------------------
class RGBDownloaderDialog(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("INPE STAC Server  (Coleção: Sentinel-2/MSI - Level 2A - Data Cube - LCF 16 days) - by Garga")
        self.setMinimumWidth(600)

        tabs = QtWidgets.QTabWidget()
        
        
# === ABA 1: Tiles, Data, Diretorio Saida, Opções de Criação ===
        main_widget = QtWidgets.QWidget()
        main_layout = QtWidgets.QVBoxLayout()
        

        self.tile_input = QtWidgets.QLineEdit()
        self.tile_input.setPlaceholderText("Ex: 003016,032010")
        main_layout.addWidget(QtWidgets.QLabel("Entre com a Lista de Tiles BDC separados por vírgulas ou espaços:"))
        main_layout.addWidget(self.tile_input)

        self.date_input = QtWidgets.QLineEdit()
        self.date_input.setPlaceholderText("Ex: 20250401")
        main_layout.addWidget(QtWidgets.QLabel("Informe a Data da Coleção (Formato: yyyymmdd):"))
        main_layout.addWidget(self.date_input)

        self.folder_input = QtWidgets.QLineEdit()
        folder_layout = QtWidgets.QHBoxLayout()
        folder_button = QtWidgets.QPushButton("Escolher pasta")
        folder_button.clicked.connect(self.select_folder)
        folder_layout.addWidget(self.folder_input)
        folder_layout.addWidget(folder_button)
        main_layout.addWidget(QtWidgets.QLabel("Pasta de destino:"))
        main_layout.addLayout(folder_layout)

        self.download_button = QtWidgets.QPushButton("Opção 1 >>>>>     Criar RGB em 8bits - (B08_B11_B04)")
        self.download_button.clicked.connect(lambda: self.process_rgb(["B08", "B11", "B04"]))
        main_layout.addWidget(self.download_button)

        self.download_button_alt = QtWidgets.QPushButton("Opção 2 >>>>>     Criar RGB em 8bits - (B03_B04_B02)")
        self.download_button_alt.clicked.connect(lambda: self.process_rgb(["B03", "B04", "B02"]))
        main_layout.addWidget(self.download_button_alt)

        # Seção de seleção de bandas
        self.band_checkboxes = {}
        bands = ["B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B8A", "B09", "B11", "B12", "NDVI", "EVI", "NBR", "SCL"]
        band_group = QtWidgets.QGroupBox("Selecionar bandas para download individual, caso deseje utilizar a opção 3:")
        band_layout = QtWidgets.QGridLayout()
        for i, band in enumerate(bands):
            checkbox = QtWidgets.QCheckBox(band)
            self.band_checkboxes[band] = checkbox
            band_layout.addWidget(checkbox, i // 4, i % 4)
        band_group.setLayout(band_layout)
        main_layout.addWidget(band_group)

        self.download_selected_button = QtWidgets.QPushButton("Opção 3 >>>>>     Download das bandas originais acima selecionadas")
        self.download_selected_button.clicked.connect(self.download_selected_bands)
        main_layout.addWidget(self.download_selected_button)

        self.tiles_processed_output = QtWidgets.QTextEdit()
        self.tiles_processed_output.setReadOnly(True)
        main_layout.addWidget(QtWidgets.QLabel("Logs de Processamento:"))
        main_layout.addWidget(self.tiles_processed_output)

        
        main_widget.setLayout(main_layout)
        tabs.addTab(main_widget, "Download e Criação de RGB")
        
        
# === ABA 2: Tile, textos explicativos e Período desejado===
        data_widget = QtWidgets.QWidget()
        data_layout = QtWidgets.QVBoxLayout()

        self.tile_check_input = QtWidgets.QLineEdit()
        self.tile_check_input.setPlaceholderText("Ex: 027022")
        data_layout.addWidget(QtWidgets.QLabel("Informe um Tile BDC para realizar a busca (formato BBBPPP):"))
        data_layout.addWidget(self.tile_check_input)

        data_layout.addWidget(QtWidgets.QLabel(""))
        data_layout.addWidget(QtWidgets.QLabel("Esta coleção possui dados desde 01/01/2017 com um intervalo de 16 dias entre cada mosaico."))
        data_layout.addWidget(QtWidgets.QLabel("Selecionar um período maior do que um ano pode causar lentidão na pesquisa !"))
        data_layout.addWidget(QtWidgets.QLabel(""))
        date_range_layout = QtWidgets.QHBoxLayout()
        self.date_start = QtWidgets.QDateEdit()
        self.date_start.setCalendarPopup(True)
        self.date_start.setDisplayFormat("yyyy-MM-dd")
        self.date_start.setDate(datetime.today().replace(month=1, day=1))

        self.date_end = QtWidgets.QDateEdit()
        self.date_end.setCalendarPopup(True)
        self.date_end.setDisplayFormat("yyyy-MM-dd")
        self.date_end.setDate(datetime.today())

        date_range_layout.addWidget(QtWidgets.QLabel("Data Inicial:"))
        date_range_layout.addWidget(self.date_start)
        date_range_layout.addWidget(QtWidgets.QLabel("Data Final:"))
        date_range_layout.addWidget(self.date_end)
        data_layout.addLayout(date_range_layout)

        check_button = QtWidgets.QPushButton("🔍 Buscar Datas no Servidor")
        check_button.clicked.connect(self.buscar_datas_validas)
        data_layout.addWidget(check_button)

        self.output_datas_validas = QtWidgets.QTextEdit()
        self.output_datas_validas.setReadOnly(True)
        data_layout.addWidget(QtWidgets.QLabel("Datas válidas encontradas:"))
        data_layout.addWidget(self.output_datas_validas)

        data_widget.setLayout(data_layout)
        tabs.addTab(data_widget, "Pesquisa de Datas da Coleção")

        # Layout principal
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.addWidget(tabs)
        self.setLayout(main_layout)
#-------------------------------FIM GERAÇÃO DA INTERFACE------------------------------------        
        
        
        
#-------------------------------PROCESSOS DA ABA 1------------------------------------
    def select_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Selecione a pasta de destino")
        if folder:
            self.folder_input.setText(folder)

    def process_rgb(self, band_order):
        tiles_input = self.tile_input.text().strip()
        tiles = [tile.strip() for tile in re.split(r'[,; ]+', tiles_input) if tile.strip()]
        date_str = self.date_input.text()
        folder = self.folder_input.text()

        # if not tiles or not date_str or not folder:
        if not tiles:    
            QtWidgets.QMessageBox.warning(self, "Erro", "Por favor, informe o(s) Tile(s)!")
            return
            
        # ✅ Validação de formato BBBPPP (ex: 028032)
        tiles_validos = [tile for tile in tiles if re.match(r"^\d{6}$", tile)]
        tiles_invalidos = [tile for tile in tiles if not re.match(r"^\d{6}$", tile)]

        if tiles_invalidos:
            QtWidgets.QMessageBox.warning(
                self, 
                "Erro", 
                f"Tile(s) inválido(s) detectado(s): {', '.join(tiles_invalidos)}\nUse o formato BBBPPP (ex: 028032)."
            )
            return
     

        if not date_str:
            QtWidgets.QMessageBox.warning(self, "Erro", "Por favor, informe a Data!")
            return
            
        if not folder:
            QtWidgets.QMessageBox.warning(self, "Erro", "Por favor, informe o Diretório!!")
            return    
        
        if len(date_str) != 8 or not date_str.isdigit():
            QtWidgets.QMessageBox.warning(self, "Erro", "A data deve ter o formato AAAAMMDD!")
            return
        if not os.path.exists(folder):
            os.makedirs(folder)

        year, month, day = date_str[:4], date_str[4:6], date_str[6:8]

        for tile in tiles:
            bbb, ppp = tile[:3], tile[3:]
            url_base = f"https://data.inpe.br/bdc/data/s2-16d/v2/{bbb}/{ppp}/{year}/{month}/{day}/S2-16D_V2_{bbb}{ppp}_{date_str}"
            

            band_data = {}
            projection, geotransform = None, None
            for band_key in band_order:
                url = f"{url_base}_{band_key}.tif"
                base_name = url.split('/')[-1]
                self.tiles_processed_output.append(f"Baixando: {base_name}")
                QApplication.processEvents()

                band_bytes = self.download_file_to_memory(url)
                if band_bytes is None:
                    self.tiles_processed_output.append(f"❌ Não existe dados para a data informada!")
                    return
                vsimem_path = f"/vsimem/{tile}_{band_key}.tif"
                gdal.FileFromMemBuffer(vsimem_path, band_bytes.getvalue())
                ds = gdal.Open(vsimem_path)
                band_data[band_key] = ds.GetRasterBand(1).ReadAsArray()
                if band_key == band_order[0]:
                    projection = ds.GetProjection()
                    geotransform = ds.GetGeoTransform()

            output_name = f"S2-16D_V2_{tile}_{date_str}_{''.join(band_order)}.tif"
            output_path = os.path.join(folder, output_name)
            self.create_rgb(
                band_data[band_order[0]], band_data[band_order[1]], band_data[band_order[2]],
                output_path, projection, geotransform
            )
            raster_layer = QgsRasterLayer(output_path, output_name)
            if raster_layer.isValid():
                QgsProject.instance().addMapLayer(raster_layer)
                self.tiles_processed_output.append(f"✅ RGB criado: {output_name}")
                self.tiles_processed_output.append(f"-------------------------------------------------")
                self.tiles_processed_output.append(f"")
            else:
                self.tiles_processed_output.append(f"❌ Falha ao carregar camada: {tile}")
                self.tiles_processed_output.append(f"-------------------------------------------------")
                self.tiles_processed_output.append(f"")
            for band_key in band_order:
                gdal.Unlink(f"/vsimem/{tile}_{band_key}.tif")

        QtWidgets.QMessageBox.information(self, "Finalização", "Geração de RGB Concluído!")

    def download_selected_bands(self):
        tiles_input = self.tile_input.text().strip()
        tiles = [tile.strip() for tile in re.split(r'[,; ]+', tiles_input) if tile.strip()]
        date_str = self.date_input.text()
        folder = self.folder_input.text()
        selected_bands = [b for b, cb in self.band_checkboxes.items() if cb.isChecked()]

        if not tiles or not date_str or not folder or not selected_bands:
            QtWidgets.QMessageBox.warning(self, "Erro", "Preencha todos os campos e selecione ao menos uma banda!")
            return
        if not os.path.exists(folder):
            os.makedirs(folder)

        year, month, day = date_str[:4], date_str[4:6], date_str[6:8]
        
        # ✅ Validação de formato BBBPPP (ex: 028032)
        tiles_validos = [tile for tile in tiles if re.match(r"^\d{6}$", tile)]
        tiles_invalidos = [tile for tile in tiles if not re.match(r"^\d{6}$", tile)]

        if tiles_invalidos:
            QtWidgets.QMessageBox.warning(
                self, 
                "Erro", 
                f"Tile(s) inválido(s) detectado(s): {', '.join(tiles_invalidos)}\nUse o formato BBBPPP (ex: 028032)."
            )
            return
 

        for tile in tiles:
            bbb, ppp = tile[:3], tile[3:]
            url_base = f"https://data.inpe.br/bdc/data/s2-16d/v2/{bbb}/{ppp}/{year}/{month}/{day}/S2-16D_V2_{bbb}{ppp}_{date_str}"

            for band_key in selected_bands:
                url = f"{url_base}_{band_key}.tif"
                base_name = url.split('/')[-1]
                self.tiles_processed_output.append(f"Baixando: {base_name}")
                QApplication.processEvents()

                band_bytes = self.download_file_to_memory(url)
                if band_bytes is None:
                    self.tiles_processed_output.append(f"❌ Não existe dados para a data informada!")
                    continue

                output_path = os.path.join(folder, base_name)
                with open(output_path, 'wb') as f:
                    f.write(band_bytes.getvalue())
                raster_layer = QgsRasterLayer(output_path, base_name)
                if raster_layer.isValid():
                    QgsProject.instance().addMapLayer(raster_layer)
                    self.tiles_processed_output.append(f"✅ Banda salva: {base_name}")
                    self.tiles_processed_output.append(f"-------------------------------------------------")
                    self.tiles_processed_output.append(f"")
                else:
                    self.tiles_processed_output.append(f"❌ Falha ao carregar: {base_name}")
        
        QtWidgets.QMessageBox.information(self, "Finalização", "Download de Bandas Concluído!")

    def normalize_to_8bit(self, array):
        array_min = np.min(array)
        array_max = np.max(array)
        return (((array - array_min) / (array_max - array_min)) * 255).astype(np.uint8)

    def create_rgb(self, r, g, b, output_path, projection, geotransform):
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, r.shape[1], r.shape[0], 3, gdal.GDT_Byte)
        out_ds.SetProjection(projection)
        out_ds.SetGeoTransform(geotransform)
        out_ds.GetRasterBand(1).WriteArray(self.normalize_to_8bit(r))
        out_ds.GetRasterBand(2).WriteArray(self.normalize_to_8bit(g))
        out_ds.GetRasterBand(3).WriteArray(self.normalize_to_8bit(b))
        out_ds.FlushCache()
        out_ds = None

    def download_file_to_memory(self, url):
      
        try:
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                return BytesIO(r.content)
        except Exception as e:
            print(f"Erro ao baixar: {e}")
            return None
#-------------------------------FIM PROCESSOS ABA 1------------------------------------



#-------------------------------PROCESSO ABA 2------------------------------------
    def buscar_datas_validas(self):
        tile = self.tile_check_input.text().strip()
        if not tile or len(tile) != 6:
            QtWidgets.QMessageBox.warning(self, "Erro", "Informe um tile válido (formato BBBPPP)")
            return

        bbb, ppp = tile[:3], tile[3:]
        data_inicial = self.date_start.date().toPyDate()
        data_final = self.date_end.date().toPyDate()

        if data_inicial > data_final:
            QtWidgets.QMessageBox.warning(self, "Erro", "A data inicial deve ser anterior à final")
            return

        self.output_datas_validas.clear()
        self.output_datas_validas.append(f"🔍 Buscando datas disponíveis para o tile {tile} entre {data_inicial} e {data_final}...")

        datas_validas = []
        data_atual = data_inicial

        while data_atual <= data_final:
            y, m, d = data_atual.strftime("%Y"), data_atual.strftime("%m"), data_atual.strftime("%d")
            date_str = f"{y}{m}{d}"
            url = f"https://data.inpe.br/bdc/data/s2-16d/v2/{bbb}/{ppp}/{y}/{m}/{d}/S2-16D_V2_{bbb}{ppp}_{date_str}_B02.tif"

            try:
                response = requests.head(url, timeout=5)
                if response.status_code == 200:
                    datas_validas.append(date_str)
                    self.output_datas_validas.append(f"✅ {date_str}")
                # else:
                    # self.output_datas_validas.append(f"❌ {date_str} (não encontrado)")
            except:
                self.output_datas_validas.append(f"⚠️ Erro em {date_str}")
            QtWidgets.QApplication.processEvents()
            data_atual += timedelta(days=1)

        self.output_datas_validas.append(f"\n📅 Total de datas encontradas: {len(datas_validas)}")
        
#-------------------------------FIM PROCESSO ABA 2------------------------------------





# Para executar no console do QGIS:
dialog = RGBDownloaderDialog()
dialog.show()