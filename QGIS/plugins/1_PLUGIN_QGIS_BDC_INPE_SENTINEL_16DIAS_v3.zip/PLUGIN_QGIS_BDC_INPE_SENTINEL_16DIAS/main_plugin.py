# BDC_INPE_SENTINEL.py
# Plugin QGIS para baixar as imagens do BDC SENTINEL, gerando camadas RGB
#-----------------------------------------------------------------------------------------------

# Classes Qt	componentes (widgets) usados para montar janelas, botões, campos de texto, etc.
# QWidget	Componente base / janela
# QVBoxLayout	Layout vertical
# QLabel	Texto/imagem
# QDateEdit	Selecionar datas
# QPushButton	Botão
# QTextEdit	Caixa de texto grande
# QComboBox	Menu dropdown
# QFileDialog	Abrir/salvar arquivos
# QApplication	Controla a aplicação
# QTabWidget	Abas
# QLineEdit	Campo de texto simples
# QAction	Ação para menus/atalhos


# Classes PyQGIS 	manipular camadas raster, projetos, renderização e simbolização
# QgsRasterLayer	Carrega e representa um raster no QGIS
# QgsProject	Interface com o projeto QGIS atual (adicionar camadas, salvar, etc.)
# QgsRasterShader	Define regras de coloração para raster
# QgsColorRampShader	Cria gradientes e rampas de cor para raster
# QgsSingleBandPseudoColorRenderer	Aplica o shader e renderiza rasters de banda única





# Importação de Bibliotecas

import os # permite interagir com o sistema operacional.
import re # procurar, validar e manipular padrões em textos
import numpy as np # para trabalhar com os array na normalização de 8 bits 
import requests # usada para fazer requisições HTTP

import pystac_client

# PyQt > para toda a interface gráfica
from qgis.PyQt import QtWidgets
from qgis.core import QgsRasterLayer, QgsProject
from PyQt5.QtWidgets import QApplication, QTabWidget, QAction
from PyQt5.QtCore import Qt

from osgeo import gdal
from io import BytesIO

from datetime import datetime, timedelta # Ele é usado para somar, subtrair ou representar durações de tempo

from qgis.PyQt.QtGui import QIcon
#-----------------------------FIM Importação de Bibliotecas -----------------------------------------------------------------------------------------------------------



#-------------------------------GERAÇÃO DA INTERFACE------------------------------------
class RGBDownloaderDialog(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BDC INPE – Sentinel-2/MSI L2A | LCF 16 days – by Garga") #Titulo da Interface
        self.setMinimumWidth(600) # setar tamanho minimo

        tabs = QtWidgets.QTabWidget()# divide em 2 abas
        
        
# === ABA 1: Tiles, Data, Diretorio Saida, Opções de Criação ===
        main_widget = QtWidgets.QWidget() # para os botões campos
        main_layout = QtWidgets.QVBoxLayout() # para os textos titulos dos campos
        

        stac_label = QtWidgets.QLabel("<b>STAC API:</b> https://data.inpe.br/bdc/stac/v1/")
        stac_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        stac_label.setStyleSheet("color: #555555;")
        main_layout.addWidget(stac_label)
        
        
        self.tile_input = QtWidgets.QLineEdit() #campo de digitação1
        self.tile_input.setPlaceholderText("Ex: 003016,032010") # coloca este texto como exemplo dentro do campo de digitação1
        main_layout.addWidget(QtWidgets.QLabel("Entre com a Lista de Tiles BDC separados por vírgulas ou espaços:")) # titulo que fica acima do campo de digitação1
        main_layout.addWidget(self.tile_input) # Inseri titulo acima do campo de digitação1

        self.date_input = QtWidgets.QLineEdit()#campo de digitação2
        self.date_input.setPlaceholderText("Ex: 20250401")# coloca este texto como exemplo dentro do campo de digitação2
        main_layout.addWidget(QtWidgets.QLabel("Informe a Data da Coleção (Formato: yyyymmdd):"))# titulo que fica acima do campo de digitação
        main_layout.addWidget(self.date_input)# Inseri titulo acima do campo de digitação2

        self.folder_input = QtWidgets.QLineEdit()#campo de digitação3 vem vazio
        folder_layout = QtWidgets.QHBoxLayout()
        folder_button = QtWidgets.QPushButton("Escolher pasta") # Botão ao lado do campo de digitação3
        folder_button.clicked.connect(self.select_folder) # abrir janela para seleção de diretorio qdo clicar
        folder_layout.addWidget(self.folder_input) # adiciona campo na nova janela que abre
        folder_layout.addWidget(folder_button)
        main_layout.addWidget(QtWidgets.QLabel("Pasta de destino:"))# titulo que fica acima do campo de digitação3
        main_layout.addLayout(folder_layout)#campo de digitação3 recebe valor

        
        #Botão de Execução 1 
        self.download_button_alt = QtWidgets.QPushButton("Opção 1 >>>>>  Criar VRT - (B08_B11_B04) - Para Visualização Rápida")#define texto do botão
        self.download_button_alt.clicked.connect(self.process_rgb_stac_vrt)
        main_layout.addWidget(self.download_button_alt)#adiciona  botão

        #Botão de Execução 2
        self.download_button = QtWidgets.QPushButton("Opção 2 >>>>>  Criar RGB em 8bits - (B08_B11_B04) - Para Interpretação") #define texto do botão
        self.download_button.clicked.connect(lambda: self.process_rgb(["B08", "B11", "B04"]))
        main_layout.addWidget(self.download_button) #adiciona  botão

        # CAMPO para Seção de seleção de bandas
        self.band_checkboxes = {}
        bands = ["B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B8A", "B09", "B11", "B12", "NDVI", "EVI", "NBR", "SCL"] # opçoes de escolha dentro do campo
        band_group = QtWidgets.QGroupBox("Selecionar bandas para download individual, caso deseje utilizar a opção 3:")#define texto que fica acima do campo
        band_layout = QtWidgets.QGridLayout() # define campo como um Grid
        for i, band in enumerate(bands):
            checkbox = QtWidgets.QCheckBox(band)
            self.band_checkboxes[band] = checkbox
            band_layout.addWidget(checkbox, i // 4, i % 4)
        band_group.setLayout(band_layout)
        main_layout.addWidget(band_group) # adiciona o grid 4x4 no campo de seleção de bandas
        
        #Botão de Execução 3
        self.download_selected_button = QtWidgets.QPushButton("Opção 3 >>>>>     Download das bandas originais acima selecionadas")#define texto do botão
        self.download_selected_button.clicked.connect(self.download_selected_bands)
        main_layout.addWidget(self.download_selected_button) #adiciona  botão

        # CAMPO para EXIBIR os LOGs de Processamento
        self.tiles_processed_output = QtWidgets.QTextEdit() # cria campo para receber  textos dos logs
        self.tiles_processed_output.setReadOnly(True)
        main_layout.addWidget(QtWidgets.QLabel("Logs de Processamento:"))#define texto do titulo do campo
        main_layout.addWidget(self.tiles_processed_output) # adiciona campo na Aba1

        
        main_widget.setLayout(main_layout)
        tabs.addTab(main_widget, "Download e Geração de Dados")  # Cria e Nomeia a ABA1 da interface
        
        
# === ABA 2: Tile, textos explicativos e Período desejado===
        data_widget = QtWidgets.QWidget()
        data_layout = QtWidgets.QVBoxLayout()

        self.tile_check_input = QtWidgets.QLineEdit()#campo de digitação4
        self.tile_check_input.setPlaceholderText("Ex: 027022") # coloca este texto como exemplo dentro do campo de digitação4
        data_layout.addWidget(QtWidgets.QLabel("Informe um Tile BDC para realizar a busca (formato BBBPPP):"))# titulo que fica acima do campo de digitação1
        data_layout.addWidget(self.tile_check_input)# Inseri titulo acima do campo de digitação4

        data_layout.addWidget(QtWidgets.QLabel("")) # Linha em branco para ganhar um espaço abaixo do campo de digitação4
        data_layout.addWidget(QtWidgets.QLabel("Esta coleção possui dados desde 01/01/2017 com um intervalo de 16 dias entre cada mosaico."))#Texto Informativo1

        data_layout.addWidget(QtWidgets.QLabel(""))# Linha em branco para ganhar um espaço abaixo dos textos informativos
        
        date_range_layout = QtWidgets.QHBoxLayout()#campo seleção de DATA INICIAL
        self.date_start = QtWidgets.QDateEdit()
        self.date_start.setCalendarPopup(True) #Exibição de Calendário
        self.date_start.setDisplayFormat("yyyy-MM-dd")
        self.date_start.setDate(datetime.today().replace(month=1, day=1))# Setar para primeiro dia do ano atual

        self.date_end = QtWidgets.QDateEdit()#campo seleção de DATA FINAL
        self.date_end.setCalendarPopup(True)#Exibição de Calendário
        self.date_end.setDisplayFormat("yyyy-MM-dd")
        self.date_end.setDate(datetime.today())# Setar para dia atual

        #ADICIONA OS CAMPOS DE DATAS FORMATADOS ACIMA
        date_range_layout.addWidget(QtWidgets.QLabel("Data Inicial:"))
        date_range_layout.addWidget(self.date_start)
        date_range_layout.addWidget(QtWidgets.QLabel("Data Final:"))
        date_range_layout.addWidget(self.date_end)
        data_layout.addLayout(date_range_layout)

        
        check_button = QtWidgets.QPushButton("🔍 Buscar Datas no Servidor")# Nome Botão de EXECUÇÃO 4
        check_button.clicked.connect(self.buscar_datas_validas)
        data_layout.addWidget(check_button) # adiciona Botão de EXECUÇÃO 4

        # CAMPO para EXIBIR os Resultados da Busca
        self.output_datas_validas = QtWidgets.QTextEdit()
        self.output_datas_validas.setReadOnly(True)
        data_layout.addWidget(QtWidgets.QLabel("Datas válidas encontradas:"))# Nome do campo de Resultados
        data_layout.addWidget(self.output_datas_validas)

        data_widget.setLayout(data_layout)
        tabs.addTab(data_widget, "Pesquisa de Datas da Coleção") # Cria e Nomeia a ABA2 da interface

        # GERAÇÃO DO Layout principal
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.addWidget(tabs)
        self.setLayout(main_layout)
#-------------------------------FIM GERAÇÃO DA INTERFACE------------------------------------        
        
        
        
#-------------------------------PROCESSOS DA ABA 1------------------------------------
    
    #Função para receber o diretorio de saida
    def select_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Selecione a pasta de destino")
        if folder:
            self.folder_input.setText(folder)

    #Função para GERAR O RGB DAS OPÇÕES 1 e 2 tratando a lista de tiles de entrada
    def process_rgb(self, band_order):
        tiles_input = self.tile_input.text().strip() # 'strip' remove espaços extras antes e depois da string
        tiles = [tile.strip() for tile in re.split(r'[,; ]+', tiles_input) if tile.strip()] ## Divide a string 'tiles_input' usando expressões regulares ,; e remove espaço
        date_str = self.date_input.text() # # Obtém o valor da entrada de texto 'date_input',
        folder = self.folder_input.text()  # Obtém o caminho do diretório de saída

        # Verifica dados do campo de TILES BDC
        if not tiles:    
            QtWidgets.QMessageBox.warning(self, "Erro", "Por favor, informe o(s) Tile(s)!")
            return
            
        # Validação de formato BBBPPP para os Tiles BDC (ex: 028032)
        tiles_validos = [tile for tile in tiles if re.match(r"^\d{6}$", tile)]
        tiles_invalidos = [tile for tile in tiles if not re.match(r"^\d{6}$", tile)]

        # Exibir msg de erro casso formato seja invalido
        if tiles_invalidos:
            QtWidgets.QMessageBox.warning(
                self, 
                "Erro", 
                f"Tile(s) inválido(s) detectado(s): {', '.join(tiles_invalidos)}\nUse o formato BBBPPP (ex: 028032)."
            )
            return
     
        # Verifica dados do campo de DATA
        if not date_str:
            QtWidgets.QMessageBox.warning(self, "Erro", "Por favor, informe a Data!")
            return
            
        # Verifica dados do campo de PASTA DESTINO    
        if not folder:
            QtWidgets.QMessageBox.warning(self, "Erro", "Por favor, informe o Diretório!!")
            return    
        
        # Verifica FORMATO dados do campo de DATA
        if len(date_str) != 8 or not date_str.isdigit():
            QtWidgets.QMessageBox.warning(self, "Erro", "A data deve ter o formato AAAAMMDD!")
            return
        
        # Verifica se Diretorio ja existe ,  senão cria ele
        if not os.path.exists(folder):
            os.makedirs(folder)

        #Recupera variaveis separadas de data
        year, month, day = date_str[:4], date_str[4:6], date_str[6:8]

        
        #Realiza a Busca
        for tile in tiles:
            bbb, ppp = tile[:3], tile[3:]
            url_base = f"https://data.inpe.br/bdc/data/s2-16d/v2/{bbb}/{ppp}/{year}/{month}/{day}/S2-16D_V2_{bbb}{ppp}_{date_str}"
            

            band_data = {}
            projection, geotransform = None, None
            for band_key in band_order:
                url = f"{url_base}_{band_key}.tif" #Configura URL para download
                base_name = url.split('/')[-1]
                self.tiles_processed_output.append(f"Baixando: {base_name}")
                QApplication.processEvents() # Atualiza mensagem de Processamentos 

                
                
                # Chama o método 'download_file_to_memory' com URL fornecida e carregar seu conteúdo na memória.               
                band_bytes = self.download_file_to_memory(url)
                
                #Verifica se há arquivos para a DATA INFORMADA
                if band_bytes is None:
                    self.tiles_processed_output.append(f"❌ Não existe dados para a data informada!")
                    return
                #Se SIM  continua processo    
                vsimem_path = f"/vsimem/{tile}_{band_key}.tif" # Cria caminho p/ arquivo virtual em memória com string formatada nome do tile e a chave do band
                gdal.FileFromMemBuffer(vsimem_path, band_bytes.getvalue()) # carregar os dados do arquivo TIFF na memória
                ds = gdal.Open(vsimem_path)# Abre o arquivo virtual que foi carregado na memória como se fosse um arquivo físico
                band_data[band_key] = ds.GetRasterBand(1).ReadAsArray() # Lê os dados da primeira banda (raster band) do arquivo TIFF
                if band_key == band_order[0]:
                    projection = ds.GetProjection()
                    geotransform = ds.GetGeoTransform() # coleta a projeção e a transformação geoespacial do arquivo.

            # Cria o nome do arquivo de saída para o raster, incorporando o tile, a data e a ordem das bandas no nome
            output_name = f"S2-16D_V2_{tile}_{date_str}_{''.join(band_order)}.tif"
            
            # Define o caminho completo onde o arquivo de saída será salvo, combinando o diretório de destino (folder) e o nome do arquivo
            output_path = os.path.join(folder, output_name)
            
            # Cria o nome da camada de saída que será usada no QGIS, novamente incorporando o tile, a data e as bandas
            output_layer = f"S2-16D_V2_{tile}_{date_str}_{''.join(band_order)}"
            
            # A função recebe os dados das bandas, o caminho do arquivo de saída, a projeção e a transformação geoespacial
            self.create_rgb(
                band_data[band_order[0]], band_data[band_order[1]], band_data[band_order[2]],
                output_path, projection, geotransform
            )
            
            # Cria uma camada raster no QGIS a partir do arquivo TIFF gerado e atribui um nome à camada
            raster_layer = QgsRasterLayer(output_path, output_layer)
            
            if raster_layer.isValid():
                QgsProject.instance().addMapLayer(raster_layer)
                self.tiles_processed_output.append(f"✅ RGB criado: {output_name}")
                self.tiles_processed_output.append(f"-------------------------------------------------")
                self.tiles_processed_output.append(f"") # # Atualiza mensagem de Processamentos  com textos , pontilhados e linhas em branco
            else:
                self.tiles_processed_output.append(f"❌ Falha ao carregar camada: {tile}")
                self.tiles_processed_output.append(f"-------------------------------------------------")
                self.tiles_processed_output.append(f"")# # Atualiza mensagem de Processamentos  com textos , pontilhados e linhas em branco
                
            for band_key in band_order:
                gdal.Unlink(f"/vsimem/{tile}_{band_key}.tif") # DELETAR DADOS DA MEMORIA

        QtWidgets.QMessageBox.information(self, "Finalização", "Geração de RGB Concluído!")
        

        
        
        

#Função para GERAR O RGB DA OPÇÃO 3 ( Bandas escolhidas na Interface)
    def download_selected_bands(self):
        tiles_input = self.tile_input.text().strip() # recebe TXT de Tiles
        tiles = [tile.strip() for tile in re.split(r'[,; ]+', tiles_input) if tile.strip()] ## Divide a string 'tiles_input' usando expressões regulares ,; e remove espaço
        date_str = self.date_input.text() # Recebe data
        folder = self.folder_input.text() # Recebe Diretorio
        selected_bands = [b for b, cb in self.band_checkboxes.items() if cb.isChecked()] # define quais bandas usar de acordo com checkbox da interface

        #Verifica Tiles, Data , Diretorio e Bandas
        if not tiles or not date_str or not folder or not selected_bands:
            QtWidgets.QMessageBox.warning(self, "Erro", "Preencha todos os campos e selecione ao menos uma banda!")
            return
        #Verifica se diretorio de saida ja existe senão cria ele
        if not os.path.exists(folder):
            os.makedirs(folder)

        #Recupera variaveis separadas de data
        year, month, day = date_str[:4], date_str[4:6], date_str[6:8]
        
        # Validação de formato BBBPPP (ex: 028032)
        tiles_validos = [tile for tile in tiles if re.match(r"^\d{6}$", tile)]
        tiles_invalidos = [tile for tile in tiles if not re.match(r"^\d{6}$", tile)]

        if tiles_invalidos:
            QtWidgets.QMessageBox.warning(
                self, 
                "Erro", 
                f"Tile(s) inválido(s) detectado(s): {', '.join(tiles_invalidos)}\nUse o formato BBBPPP (ex: 028032)."
            )
            return
 
        #Realiza a Busca
        for tile in tiles:
            bbb, ppp = tile[:3], tile[3:]
            url_base = f"https://data.inpe.br/bdc/data/s2-16d/v2/{bbb}/{ppp}/{year}/{month}/{day}/S2-16D_V2_{bbb}{ppp}_{date_str}"

            for band_key in selected_bands:
                url = f"{url_base}_{band_key}.tif"  #Configura URL para download
                base_name = url.split('/')[-1]
                self.tiles_processed_output.append(f"Baixando: {base_name}")
                QApplication.processEvents() # Atualiza mensagem de Processamentos

                band_bytes = self.download_file_to_memory(url)
                
                #Verifica se há arquivos para a DATA INFORMADA
                if band_bytes is None:
                    self.tiles_processed_output.append(f"❌ Não existe dados para a data informada!")
                    continue
                    
                #Se SIM  continua processo PARA SALVAR OS TIFS DAS BANDAS
                output_path = os.path.join(folder, base_name)
                with open(output_path, 'wb') as f:
                    f.write(band_bytes.getvalue())
                raster_layer = QgsRasterLayer(output_path, base_name)
                if raster_layer.isValid():
                    QgsProject.instance().addMapLayer(raster_layer)
                    self.tiles_processed_output.append(f"✅ Banda salva: {base_name}")
                    self.tiles_processed_output.append(f"-------------------------------------------------")
                    self.tiles_processed_output.append(f"")
                else:
                    self.tiles_processed_output.append(f"❌ Falha ao carregar: {base_name}")
        
        QtWidgets.QMessageBox.information(self, "Finalização", "Download de Bandas Concluído!")
        
#-------------------------------  FIM DA FUNÇÃO PRINCIPAL  ------------------------------------        
    
    #Função para NORMALIZAR DADOS DE SAIDA em 8 BITS
    def normalize_to_8bit(self, array):
        array_min = np.min(array)
        array_max = np.max(array)
        return (((array - array_min) / (array_max - array_min)) * 255).astype(np.uint8)

    #Função para criar os RGB de 8 bits
    def create_rgb(self, r, g, b, output_path, projection, geotransform):
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, r.shape[1], r.shape[0], 3, gdal.GDT_Byte)
        out_ds.SetProjection(projection)
        out_ds.SetGeoTransform(geotransform)
        out_ds.GetRasterBand(1).WriteArray(self.normalize_to_8bit(r))
        out_ds.GetRasterBand(2).WriteArray(self.normalize_to_8bit(g))
        out_ds.GetRasterBand(3).WriteArray(self.normalize_to_8bit(b))
        out_ds.FlushCache()
        out_ds = None

    #Função para Processar em Memoria
    def download_file_to_memory(self, url):
        try:
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                return BytesIO(r.content)
        except Exception as e:
            print(f"Erro ao baixar: {e}")
            return None

    #Função BUSCA STAC
    def search_stac_item(self, tile, date_str):
    
        client = pystac_client.Client.open("https://data.inpe.br/bdc/stac/v1/")

        date_iso = datetime.strptime(date_str, "%Y%m%d").strftime("%Y-%m-%d")
        datetime_range = f"{date_iso}T00:00:00Z/{date_iso}T23:59:59Z"

        search = client.search(
            collections=["S2-16D-2"],
            query={"bdc:tile": {"eq": tile}},
            datetime=datetime_range,
            limit=1
        )

        items = list(search.get_items())
        return items[0] if items else None


#Função GERAR VRT
    def process_rgb_stac_vrt(self):
        tiles_input = self.tile_input.text().strip()
        tiles = [tile.strip() for tile in re.split(r'[,; ]+', tiles_input) if tile.strip()]
        date_str = self.date_input.text()
        folder = self.folder_input.text()

        # Validações
        if not tiles:
            QtWidgets.QMessageBox.warning(self, "Erro", "Informe ao menos um Tile!")
            return

        if not date_str or len(date_str) != 8:
            QtWidgets.QMessageBox.warning(self, "Erro", "Informe a data no formato AAAAMMDD!")
            return

        if not folder:
            QtWidgets.QMessageBox.warning(self, "Erro", "Informe o diretório de saída!")
            return

        if not os.path.exists(folder):
            os.makedirs(folder)

        bandas = ["B08", "B11", "B04"]
        bandas_str = "_".join(bandas)

        for tile in tiles:
            self.tiles_processed_output.append(f"🔍 Buscando STAC para tile {tile} - data {date_str}")
            QApplication.processEvents()

            item = self.search_stac_item(tile, date_str)

            if not item:
                self.tiles_processed_output.append(f"❌ Nenhum item encontrado para {tile} em {date_str}")
                continue

            hrefs = []
            for band in bandas:
                if band not in item.assets:
                    self.tiles_processed_output.append(f"⚠️ Banda {band} não disponível para {tile}")
                    continue
                hrefs.append(f"/vsicurl/{item.assets[band].href}")

            if len(hrefs) != 3:
                self.tiles_processed_output.append(f"❌ Bandas incompletas para {tile}")
                continue

            vrt_name = f"S2-16D_V2_{tile}_{date_str}.vrt"
            vrt_path = os.path.join(folder, vrt_name)

            vrt = gdal.BuildVRT(
                vrt_path,
                hrefs,
                options=gdal.BuildVRTOptions(
                    separate=True,
                    addAlpha=False
                )
            )

            if vrt:
                vrt = None
                layer = QgsRasterLayer(vrt_path, vrt_name)
                if layer.isValid():
                    QgsProject.instance().addMapLayer(layer)
                    self.tiles_processed_output.append(f"✅ VRT criado: {vrt_name}")
                    self.tiles_processed_output.append("-------------------------------------------------")
                else:
                    self.tiles_processed_output.append(f"❌ Falha ao carregar VRT: {vrt_name}")
            else:
                self.tiles_processed_output.append(f"❌ Erro ao criar VRT para {tile}")

        
        QtWidgets.QMessageBox.information(self, "Finalização", "Geração de VRT Concluído!")


#-------------------------------FIM PROCESSOS ABA 1------------------------------------



#-------------------------------PROCESSO ABA 2------------------------------------
    
    #Função para varrer e Listar as datas de BDC disponiveis no periodo informado
    def buscar_datas_validas(self):
        tile = self.tile_check_input.text().strip()
        if not tile or len(tile) != 6:
            QtWidgets.QMessageBox.warning(self, "Erro", "Informe um tile válido (formato BBBPPP)")
            return

        data_inicial = self.date_start.date().toPyDate()
        data_final = self.date_end.date().toPyDate()

        if data_inicial > data_final:
            QtWidgets.QMessageBox.warning(self, "Erro", "A data inicial deve ser anterior à final")
            return

        self.output_datas_validas.clear()
        self.output_datas_validas.append(
            f"🔍 Buscando datas disponíveis (STAC) para o tile {tile} entre {data_inicial} e {data_final}..."
        )

        # ---------------- STAC ----------------
        client = pystac_client.Client.open(
            "https://data.inpe.br/bdc/stac/v1/"
        )

        datetime_range = (
            f"{data_inicial.isoformat()}T00:00:00Z/"
            f"{data_final.isoformat()}T23:59:59Z"
        )

        search = client.search(
            collections=["S2-16D-2"],
            query={"bdc:tile": {"eq": tile}},
            datetime=datetime_range
        )

        items = list(search.get_items())

        # --------------------------------------

        datas_validas = sorted({
            item.datetime.strftime("%Y%m%d")
            for item in items
        })

        for date_str in datas_validas:
            self.output_datas_validas.append(f"✅ {date_str}")
            QtWidgets.QApplication.processEvents()

        self.output_datas_validas.append(
            f"\n📅 Total de datas encontradas: {len(datas_validas)}"
        )

        
#-------------------------------FIM PROCESSO ABA 2------------------------------------


# Para executar no console do QGIS:
# dialog = RGBDownloaderDialog()
# dialog.show()

# E COMENTAR TUDO ABAIXO !!!!!!!!!!!!
#--------------------------------- PARTE ESPECIFICA PARA PLUGIN---------------------------------------


#QGIS carrega o plugin automaticamente por meio da função classFactory
#O initGui() registra o plugin no menu e na barra de ferramentas do QGIS.
def classFactory(iface):
    return BDC_INPE_Sentinel2_Plugin(iface)


class BDC_INPE_Sentinel2_Plugin:
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon_BDC.png")
        self.action = QAction(QIcon(icon_path), "BDC INPE SENTINEL 16 DIAS", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("BIOMASBR_CERRADO", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("BIOMASBR_CERRADO", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        if self.dialog is None:
            self.dialog = RGBDownloaderDialog()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()




