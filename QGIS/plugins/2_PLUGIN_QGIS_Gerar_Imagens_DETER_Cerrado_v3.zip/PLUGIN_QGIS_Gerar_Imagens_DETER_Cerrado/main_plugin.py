# Download DETER Cerrado.py
# Plugin QGIS para baixar as imagens do dia/satelite selecionado, gerando camadas RGB
#-----------------------------------------------------------------------------------------------

# Classes Qt	componentes (widgets) usados para montar janelas, botões, campos de texto, etc.
# QWidget	Componente base / janela
# QVBoxLayout	Layout vertical
# QLabel	Texto/imagem
# QDateEdit	Selecionar datas
# QPushButton	Botão
# QTextEdit	Caixa de texto grande
# QComboBox	Menu dropdown
# QFileDialog	Abrir/salvar arquivos
# QApplication	Controla a aplicação
# QTabWidget	Abas
# QLineEdit	Campo de texto simples
# QAction	Ação para menus/atalhos


# Classes PyQGIS 	manipular camadas raster, projetos, renderização e simbolização
# QgsRasterLayer	Carrega e representa um raster no QGIS
# QgsProject	Interface com o projeto QGIS atual (adicionar camadas, salvar, etc.)
# QgsRasterShader	Define regras de coloração para raster
# QgsColorRampShader	Cria gradientes e rampas de cor para raster
# QgsSingleBandPseudoColorRenderer	Aplica o shader e renderiza rasters de banda única



# Importação de Bibliotecas

import requests # usada para fazer requisições HTTP
import os # permite interagir com o sistema operacional.
import re # procurar, validar e manipular padrões em textos
import processing  # Verificar necessidade
import numpy as np # para trabalhar com os array na normalização de 8 bits 
import urllib.request # Verificar necessidade

# PyQt > para toda a interface gráfica
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QLabel, QDateEdit, QPushButton, QTextEdit, QComboBox, QFileDialog, QApplication, QTabWidget, QLineEdit, QAction)
from qgis.core import (QgsRasterLayer, QgsProject, QgsRasterShader, QgsColorRampShader, QgsSingleBandPseudoColorRenderer)
from PyQt5.QtCore import QDate # representa uma data sem hora, manipular datas em widgets de data

from datetime import datetime
from osgeo import gdal  
from io import BytesIO  
from pathlib import Path

from qgis.PyQt.QtGui import QIcon # Para definir Icones
#-----------------------------FIM Importação de Bibliotecas -----------------------------------------------------------------------------------------------------------





#--------------------------------- DEFINIR INTERFACE QGIS---------------------------------------
def create_interface():
    widget = QWidget()
    widget.setWindowTitle("DETER IMAGENS - By Garga")  # Define o título da janela
    widget.resize(500, 400)  # Definir o tamanho da janela
    layout = QVBoxLayout()

# Criando o QTabWidget
    tabs = QTabWidget()
    
# PRIMEIRA ABA DA INTERFACE (Servidor Interno)
    tab1 = QWidget()
    tab1_layout = QVBoxLayout()
    
# Campos para Data
    label_fonte = QLabel("Fonte > http://cbers9.dpi.inpe.br:8089/files/") # define texto que vai ficar acima do campo Data
    tab1_layout.addWidget(label_fonte) # adiciona o texto
    label = QLabel("Informe a Data das Imagens:") # define texto que vai ficar acima do campo Data
    tab1_layout.addWidget(label) # adiciona o texto
    
    date_edit = QDateEdit() # cria campo Data
    date_edit.setCalendarPopup(True) # Configura como Calendário para aparecer se for editar nova data
    date_edit.setDate(QDate.currentDate()) # recupera dia atual
    tab1_layout.addWidget(date_edit) # adiciona data na interface

# Campos para Satelite    
    label_sat = QLabel("Selecione Satélite:")
    tab1_layout.addWidget(label_sat)
    
    satellite_selector = QComboBox()# configura campo como SELETOR DE ITENS
    satellite_selector.addItems(["Amazonia-1", "CBERS-4A", "CBERS-4"])
    tab1_layout.addWidget(satellite_selector)# adiciona seletor
    
    log_widget = QTextEdit() # configura campo como area para exibir mensagens LOGs
    log_widget.setReadOnly(True)
    tab1_layout.addWidget(log_widget) #adiciona area de mensagens

# Campos para Diretorio Saida      
    default_path = os.path.expanduser("~/Downloads/DETER_IMG") # configura diretorio DEFAULT para ser utilizado caso usuario nao escolha outro
    os.makedirs(default_path, exist_ok=True)
    destination_folder = [default_path]
    log_widget.append(f"Pasta de Destino Padrão  >>  Downloads\DETER_IMG")

    btn_select_folder = QPushButton("Alterar Pasta de Destino") # cria botão para selecionar outro diretorio de saida
    btn_select_folder.clicked.connect(lambda: select_folder(destination_folder, log_widget))
    tab1_layout.addWidget(btn_select_folder)

# Botão Executar    
    btn_download = QPushButton("EXECUTAR")
    btn_download.clicked.connect(lambda: process_date(date_edit.date(), satellite_selector.currentText(), log_widget, destination_folder[0]))
    tab1_layout.addWidget(btn_download)
    
    tab1.setLayout(tab1_layout)
    tabs.addTab(tab1, "SERVIDOR INTERNO") # Cria e  exibe o nome da ABA1 como SERVIDOR INTERNO
  


  
# SEGUNDA ABA (Lista_Catalogo de Imagens)
    tab2 = QWidget()
    tab2_layout = QVBoxLayout()
    
    tab2.setLayout(tab2_layout)
    tabs.addTab(tab2, "ARQUIVO TXT") # Cria e  exibe o nome da ABA2 como CATÁLOGO DGI
    
    
# Campo para selecionar arquivo TXT obtido no site oficial do INPE com as imagens escolhidas
    txt_file_label = QLabel("Adicione o arquivo TXT que contém as URLs das imagens selecionadas, obtidas em :")
    tab2_layout.addWidget(txt_file_label)
    txt_file_label2 = QLabel("Fonte_1 > https://www.dgi.inpe.br/catalogo/explore")
    tab2_layout.addWidget(txt_file_label2)
    txt_file_label3 = QLabel("Fonte_2 > https://data.inpe.br/bdc/explorer/explore")
    tab2_layout.addWidget(txt_file_label3)
    
    txt_file_input = QLineEdit() # campo para exibir o nome o TXT  escolhido
    tab2_layout.addWidget(txt_file_input)
    
    txt_file_button = QPushButton("Escolher arquivo TXT")
    txt_file_button.clicked.connect(lambda: select_txt_file(txt_file_input)) #abre janela windows para escolha de arquivo
    tab2_layout.addWidget(txt_file_button)
    
# Campo de log para exibir mensagens da aba 2
    log_widget_tab2 = QTextEdit()
    log_widget_tab2.setReadOnly(True)
    tab2_layout.addWidget(log_widget_tab2)
  
#Diretório de saída da ABA2
    btn_select_folder2 = QPushButton("Alterar Pasta de Destino")
    btn_select_folder2.clicked.connect(lambda: select_folder(destination_folder, log_widget_tab2))
    log_widget_tab2.append(f"Pasta de Destino Padrão  >>  Downloads\DETER_IMG")
    tab2_layout.addWidget(btn_select_folder2)

    
# Botão para Baixar Imagens
    btn_download_catalog = QPushButton("EXECUTAR")
    btn_download_catalog.clicked.connect(lambda: process_catalog(txt_file_input.text(), destination_folder[0], log_widget_tab2))
    tab2_layout.addWidget(btn_download_catalog)
    
    
# Adicionando as ABAS ao layout principal
    layout.addWidget(tabs)
    widget.setLayout(layout)
    # widget.show()
    return widget

#--------------------------------- FIM INTERFACE QGIS---------------------------------------



# CRIAR INTERFACE
dlg = create_interface()


    
# SELEÇÃO FOLDER DESTINO
def select_folder(destination_folder, log_widget):
    folder = QFileDialog.getExistingDirectory(None, "Selecione a pasta de destino", os.path.expanduser("~"))
    if folder:
        log_widget.clear()  # Limpa o conteúdo anterior
        destination_folder[0] = folder
        log_widget.append(f"📁 Nova Pasta de Destino:\n {Path(folder).as_posix()}")
        log_message(f"--------------------------------------------------", log_widget)
        log_message(f" ", log_widget)        
        QApplication.processEvents()
        



# EXIBIR LOGS NO CONSOLE
def log_message(message, log_widget):
    log_widget.append(message)
    print(message)
    


#--------------------------------- PROCESSAMENTO DA ABA 1---------------------------------------

# VERIFICAR ORBITAS/PONTOS DO CERRADO
def is_valid_orbit_point(orbit_point, satellite):
    valid_ranges = {
        "Amazonia-1": [
            (34, 16, 34, 19), (35, 15, 35, 19), (36, 16, 36, 19),
            (37, 17, 37, 18), (38, 17, 38, 17)
        ],
        "CBERS-4A": [
            (209, 116, 209, 148), (215, 124, 215, 140), (221, 132, 221, 140),
            (196, 132, 196, 140), (202, 116, 202, 148), (208, 116, 208, 140),
            (214, 124, 214, 140), (220, 132, 220, 140), (195, 132, 195, 140),
            (226, 124, 226, 140), (201, 116, 201, 148), (207, 116, 207, 148),
            (213, 116, 213, 140), (219, 132, 219, 140), (225, 124, 225, 132),
            (200, 116, 200, 140), (206, 116, 206, 148), (212, 116, 212, 140),
            (218, 132, 218, 140), (224, 124, 224, 132), (199, 116, 199, 140),
            (205, 116, 205, 148), (211, 116, 211, 140), (217, 132, 217, 140),
            (223, 132, 223, 132), (198, 116, 198, 140), (204, 116, 204, 148),
            (210, 116, 210, 140), (216, 124, 216, 140), (222, 124, 222, 132),
            (197, 116, 197, 140), (203, 116, 203, 148)
        ],
        "CBERS-4": [
            (156, 105, 156, 129), (173, 111, 173, 117), (164, 105, 164, 123),
            (155, 105, 155, 129), (172, 111, 172, 117), (163, 105, 163, 123),
            (154, 105, 154, 129), (171, 111, 171, 117), (162, 105, 162, 129),
            (153, 105, 153, 129), (170, 111, 170, 123), (161, 105, 161, 129),
            (152, 105, 152, 129), (169, 111, 169, 123), (160, 105, 160, 129),
            (151, 105, 151, 123), (168, 111, 168, 123), (159, 105, 159, 129),
            (150, 111, 150, 123), (167, 111, 167, 123), (158, 105, 158, 129),
            (149, 117, 149, 123), (175, 111, 175, 117), (166, 111, 166, 123),
            (157, 105, 157, 129), (174, 111, 174, 117), (148, 117, 148, 123),
            (165, 111, 165, 123)
        ]
    }
    match = re.match(r"(\d{3})_(\d{3})", orbit_point)
    #verificar quais orbitas pontos das listas acimas são validas
    if match:
        orbit, point = int(match.group(1)), int(match.group(2))
        return any(o_min <= orbit <= o_max and p_min <= point <= p_max for o_min, p_min, o_max, p_max in valid_ranges[satellite])
    return False
    

# CRIAÇÃO DA LISTA DE URLS PARA DOWNLOAD
def process_date(date, satellite, log_widget, save_dir):
    log_message(f"🛰️ Cenas do Bioma Cerrado para Data/Sensor Selecionados:", log_widget)
    log_widget.append("")
    QApplication.processEvents() # Exibir Logs no painel de informações 

    base_urls = {
        "Amazonia-1": "http://cbers9.dpi.inpe.br:8089/files/AMAZONIA1",
        "CBERS-4A": "http://cbers9.dpi.inpe.br:8089/files/CBERS4A",
        "CBERS-4": "http://cbers9.dpi.inpe.br:8089/files/CBERS4"
    }
    bands = {
        "Amazonia-1": ["L4_BAND2", "L4_BAND3", "L4_BAND4", "L4_LEFT_BAND2", "L4_LEFT_BAND3", "L4_LEFT_BAND4"],
        "CBERS-4A": ["L4_BAND13", "L4_BAND15", "L4_BAND16", "L4_LEFT_BAND13", "L4_LEFT_BAND15", "L4_LEFT_BAND16"],
        "CBERS-4": ["L4_BAND13", "L4_BAND15", "L4_BAND16", "L4_LEFT_BAND13", "L4_LEFT_BAND15", "L4_LEFT_BAND16"]
    }

    year_month = date.toString("yyyy_MM") #  recuperar ano_mes
    day = date.toString("yyyy_MM_dd") #  recuperar data completa
    day_tif = date.toString("yyyyMMdd")# transformar data em texto sem "_" para incluir nas urls de busca
    day_tif_save = date.toString("ddMMyyyy") # transformar data em texto sem "_" no formato dia mes ano
    os.makedirs(save_dir, exist_ok=True)

    date_url = f"{base_urls[satellite]}/{year_month}/"  # configurar URL completa ate ano_mes
    try:
        response = requests.get(date_url) # varrer no servidor
        if response.status_code != 200:
            log_message("🚫 Diretório remoto da data não encontrado no servidor.", log_widget)
            log_message(f"--------------------------------------------------", log_widget)
            log_message(f" ", log_widget)        
            QApplication.processEvents() # Atualizar msg no painel
            return
    except Exception as e:
        log_message(f"❌ Erro ao acessar o servidor: {e}", log_widget)
        log_message(f"--------------------------------------------------", log_widget)
        log_message(f" ", log_widget)        
        
        QApplication.processEvents() # Atualizar msg no painel
        return
    #Fazer a busca na URL dinamica abaixo
    scene_dirs = re.findall(
        rf"({satellite.upper().replace('-', '_')}_(?:WFI_RAW|AWFI_DRD)_{day}\.\d{{2}}_\d{{2}}_\d{{2}}_[A-Z0-9]+)/",
        response.text
    )

    if not scene_dirs:
        log_message("⚠️ Nenhuma cena encontrada para esta data e sensor.", log_widget)
        log_message(f"--------------------------------------------------", log_widget)
        log_message(f" ", log_widget)        
        QApplication.processEvents() # Atualizar msg no painel
        return

    urls_orbitas_pontos = [] # cria Lista vazia para incluir as orbitas pontos
    processed_orbits = set()
    for scene in scene_dirs:
        scene_url = f"{date_url}{scene}/"
        response_scene = requests.get(scene_url) # busca diretorio especifico
        if response_scene.status_code != 200:
            log_message(f"⚠️ Cena ignorada: diretório {scene} não encontrado.", log_widget)
            log_message(f"--------------------------------------------------", log_widget)
            log_message(f" ", log_widget)        
            QApplication.processEvents()
            continue

        orbit_dirs = re.findall(r"(\d{3}_\d{3}_0)/", response_scene.text) # busca cenas dentro do diretorio
        if not orbit_dirs:
            log_message(f"⚠️ Nenhuma órbita-ponto encontrada na cena {scene}.", log_widget)
            log_message(f"--------------------------------------------------", log_widget)
            log_message(f" ", log_widget)        
            QApplication.processEvents()
            continue

        for orbit_point in orbit_dirs:
            if orbit_point in processed_orbits or not is_valid_orbit_point(orbit_point, satellite):
                continue
            processed_orbits.add(orbit_point)# adiciona valores das orbitas pontos

            log_message(f"Satélite {satellite} : {'_'.join(orbit_point.split('_')[:2])}", log_widget)
            QApplication.processEvents() # Atualizar msg no painel
            
            #define parte da URL de acordo com satelite escolhido
            projection_folder = "4_BC_LCC_WGS84" if satellite == "Amazonia-1" else "4_BC_UTM_WGS84"

            #Configura parte da URL final de download 
            bands_url = f"{scene_url}{orbit_point}/{projection_folder}/"
            
            #define parte da URL de acordo com satelite escolhido
            sensor = "WFI" if satellite in ["Amazonia-1", "CBERS-4A"] else "AWFI"
            
            #Monta URL FINAL  para cada imagem e acrescenta na Lista
            filename = f"{satellite.upper().replace('-', '_')}_{sensor}_{day_tif}_{orbit_point[:7]}"
            urls_orbitas_pontos.append(f"{bands_url}{filename}")

    
    #Verifica se Lista é vazia para informar no painel de msg
    if not urls_orbitas_pontos:
        log_message("⚠️ Nenhuma imagem disponível para download com os critérios informados.", log_widget)
        log_message(f"--------------------------------------------------", log_widget)
        log_message(f" ", log_widget)        
        QApplication.processEvents() # Atualizar msg no painel
        return
    
    #Se lista não é vazia continua o processo
    log_message(" ", log_widget)
    log_message("🔄 Iniciando download e geração de RGB...", log_widget)
    QApplication.processEvents()# Atualizar msg no painel

    #Chama função PRICIPAL  para baixar as imagens e gerar RGB
    download_and_create_rgb(urls_orbitas_pontos, save_dir, satellite, log_widget)

    

# Função para testar dois sufixos : L4 ou L4_LEFT  pois pode existir estes 2 tipos de arquivos tif no servidor
def tentar_baixar_banda(url_base, sufixo1, sufixo2):
    url_tentativa1 = f"{url_base}_{sufixo1}.tif"
    url_tentativa2 = f"{url_base}_{sufixo2}.tif"
    
    conteudo = download_file_to_memory(url_tentativa1)
    if conteudo:
        return conteudo
    else:
        return download_file_to_memory(url_tentativa2)


# Função PRINCIPAL para baixar as bandas e criar a composição RGB
# variaveis de entrada: Lista de URLS, diretorio de saida, Satelite e mensagens )
def download_and_create_rgb(urls, destination_folder, satellite, log_widget):
    rgb_created = False
    for url_base in urls:
        base_name = url_base.split('/')[-1]  # Obtém o nome base da URL base (ex: AMAZONIA_1_WFI_20250408_034_019)
        
        parts = base_name.split('_') # divide em partes
        satellite_raw = parts[0] + "_" + parts[1]  # ex: 'AMAZONIA_1', 'CBERS_4', 'CBERS_4A'
        satelname = satellite_raw.replace('_', '-')  # ex: 'AMAZONIA-1', 'CBERS-4', 'CBERS-4A'
        sensor = parts[2]  # 'WFI' ou 'AWFI'
        date_str = parts[3]  # '20250406'
        orbit = parts[4]
        point = parts[5]
        formatted_date = f"{date_str[6:8]}{date_str[4:6]}{date_str[0:4]}"
        
        #configura variavel base com os parametros obtidos acima
        base_name2 = f"{satelname}_{sensor}_{orbit}_{point}_{formatted_date}"
        
            
        if satellite == "Amazonia-1": 
            sufixo = "8bits_432"
            band1_mem = tentar_baixar_banda(url_base, "L4_BAND4", "L4_LEFT_BAND4")
            band2_mem = tentar_baixar_banda(url_base, "L4_BAND3", "L4_LEFT_BAND3")
            band3_mem = tentar_baixar_banda(url_base, "L4_BAND2", "L4_LEFT_BAND2")
        else:
            sufixo = "8bits_161513"
            band1_mem = tentar_baixar_banda(url_base, "L4_BAND16", "L4_LEFT_BAND16")
            band2_mem = tentar_baixar_banda(url_base, "L4_BAND15", "L4_LEFT_BAND15")
            band3_mem = tentar_baixar_banda(url_base, "L4_BAND13", "L4_LEFT_BAND13")
             
                
        # Verifica se todas as bandas foram baixadas com sucesso
        if band1_mem and band2_mem and band3_mem:
            
            # Converte os dados em memória para um VRT no sistema de arquivos virtual do GDAL
            band1_vsimem = f"/vsimem/{base_name2}_B1.tif"
            band2_vsimem = f"/vsimem/{base_name2}_B2.tif"
            band3_vsimem = f"/vsimem/{base_name2}_B3.tif"

            # Escreve as bandas temporárias em vsimem (memória virtual do GDAL)
            gdal.FileFromMemBuffer(band1_vsimem, band1_mem.getvalue())
            gdal.FileFromMemBuffer(band2_vsimem, band2_mem.getvalue())
            gdal.FileFromMemBuffer(band3_vsimem, band3_mem.getvalue())

            # Abre as bandas a partir da memória virtual
            band1 = gdal.Open(band1_vsimem)
            band2 = gdal.Open(band2_vsimem)
            band3 = gdal.Open(band3_vsimem)

            # Lê os dados das bandas como arrays
            band1_data = band1.GetRasterBand(1).ReadAsArray()
            band2_data = band2.GetRasterBand(1).ReadAsArray()
            band3_data = band3.GetRasterBand(1).ReadAsArray()


# Cria a composição RGB diretamente

            # Define o caminho do arquivo de saída       
            rgb_output = os.path.join(destination_folder, f"{base_name2}_{sufixo}.tif")   
            
            #Chama função fornecendo os 6 dados de entrada 
            rgb_composition = create_rgb_composition_in_memory(
                band1_data, 
                band2_data, 
                band3_data, 
                rgb_output, 
                band1.GetProjection(),
                band1.GetGeoTransform()
            )
            
            if rgb_composition:
                rgb_created = True
                log_message(f"✅ Composição RGB salva: {base_name2}_{sufixo}.tif", log_widget)
                QApplication.processEvents()# Vai atualizando Painel de msg conforme os RGB são criados
                
                raster_layer = QgsRasterLayer(rgb_composition, f"{base_name2}_{sufixo}")  # Cria uma camada raster no QGIS

                if not raster_layer.isValid():
                    log_message(f"Erro ao carregar a composição RGB: {base_name2}_{sufixo}", log_widget)
                    QApplication.processEvents()
                else:
                    QgsProject.instance().addMapLayer(raster_layer)  # Adiciona a camada ao projeto QGIS
                    
            else:
                log_message(f"Erro ao criar a composição RGB: {base_name2}_{sufixo}.tif", log_widget)
                QApplication.processEvents()

            # Remove os arquivos temporários da memória virtual
            gdal.Unlink(band1_vsimem)
            gdal.Unlink(band2_vsimem)
            gdal.Unlink(band3_vsimem)
        else:
            log_message(f"❌ Sem Dados no Servidor para: {base_name}", log_widget)
            QApplication.processEvents()
            
            
    log_message(f" ", log_widget) # adiciona linha vazia no painel de mensagens para simular quebra de linha
    if rgb_created:
        log_message(f"💾 Camadas RGB Criadas com Sucesso!", log_widget)
    else:
        log_message(f"⚠️ Nenhuma camada RGB foi criada.", log_widget)

    log_message(f"--------------------------------------------------", log_widget)# adiciona linha pontilhada no fim da msg
    log_message(f" ", log_widget)# adiciona linha vazia no painel de mensagens para simular quebra de linha
    
    

# Função para baixar um arquivo de uma URL e retorná-lo como BytesIO (dados em memória)
def download_file_to_memory(url):
    try:
        # Faz uma requisição GET para a URL
        with requests.get(url, stream=True) as r:
            r.raise_for_status()  # Levanta uma exceção se a requisição falhar
            return BytesIO(r.content)  # Retorna o conteúdo do arquivo em memória
    except requests.exceptions.RequestException as e:
        
        return None  # Retorna None se houver um erro

# Função para normalizar um array para 8 bits
def normalize_to_8bit(array):
    array_min = np.min(array)  # Obtém o valor mínimo do array
    array_max = np.max(array)  # Obtém o valor máximo do array
    normalized = ((array - array_min) / (array_max - array_min)) * 255  # Normaliza o array para a faixa 0-255
    return normalized.astype(np.uint8)  # Converte o array normalizado para tipo uint8

# Função para criar uma composição RGB a partir de três bandas em memória com 6 parametros de entrada necessarios
def create_rgb_composition_in_memory(band1_data, band2_data, band3_data, output_path, projection, geotransform):
    try:
        # Cria um novo arquivo GeoTIFF para a composição RGB
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, band1_data.shape[1], band1_data.shape[0], 3, gdal.GDT_Byte)
        
        # Define a projeção e a transformação geoespacial do novo arquivo
        out_ds.SetProjection(projection)
        out_ds.SetGeoTransform(geotransform)
        
        # Escreve os arrays normalizados para o novo arquivo
        out_ds.GetRasterBand(1).WriteArray(normalize_to_8bit(band1_data))
        out_ds.GetRasterBand(2).WriteArray(normalize_to_8bit(band2_data))
        out_ds.GetRasterBand(3).WriteArray(normalize_to_8bit(band3_data))
        
        out_ds.FlushCache()  # Garante que todos os dados sejam escritos no disco
        out_ds = None  # Fecha o arquivo
        
        return output_path  # Retorna o caminho do arquivo de saída
    except Exception as e:
        print(f"Erro ao criar a composição RGB: {e}")  # Imprime o erro se a criação falhar
        return None  # Retorna None se houver um erro
#--------------------------------- FIM DO PROCESSAMENTO DA ABA 1---------------------------------------







#--------------------------------- PROCESSAMENTO DA ABA 2---------------------------------------

# Definição da JANELA DE SELEÇÃO DE ARQUIVO TXT

def select_txt_file(txt_file_input):
    file, _ = QFileDialog.getOpenFileName(None, "Escolher arquivo TXT", "", "Text Files (*.txt)") # nome da janela e tipos de arquivos a serem exibidos
    if file:
        txt_file_input.setText(file) #recupera arquivo TXT selecionado
        
# Função para processar o arquivo TXT e criar as listas de URLs
def process_catalog(txt_file_path, output_dir, log_widget):
    log_widget.append("🔍 Lendo arquivo de URLs...")
    log_message(f"--------------------------------------------------", log_widget)
    log_message(f" ", log_widget)        
    QApplication.processEvents() # Atualiza painel de mensagens com as informações acima
    
    try:
        with open(txt_file_path, 'r') as file:
            # Leitura das URLs do arquivo TXT
            urls = [url.strip() for url in file.readlines()]
            # Expressão regular para validar URLs no formato esperado
            #padrao_url = re.compile(r'.*_BAND\d{1,2}\.tif\?email=.*', re.IGNORECASE)
            padrao_url = re.compile(r'.*_BAND\d{1,2}\.tif\.*', re.IGNORECASE)

            # Verifica se todas as URLs estão no formato esperado
            urls_validas = [url for url in urls if padrao_url.match(url)]
            if not urls_validas:
                if log_widget:
                    log_widget.append("❌ O arquivo TXT não contém URLs válidas no formato esperado.")
                return
            
            
            
    except Exception as e:
        log_widget.append(f"❌ Erro ao ler o arquivo TXT: {e}")
        log_message(f"--------------------------------------------------", log_widget)
        log_message(f" ", log_widget)        
        QApplication.processEvents() # Atualiza painel de mensagens com as informações acima
        return

    Amazonia1_urls, Cbers4A_urls, Cbers4_urls = [], [], []  # Crias Listas Vazias para receber as urls do arquivo TXT

    #montagem da lista de urls de acordo com as bandas necessarias ao projeto Deter
    for url in urls:
        if 'AMAZONIA_1' in url and any(b in url for b in ['BAND2.tif', 'BAND3.tif', 'BAND4.tif']):
            Amazonia1_urls.append(url)
        elif 'CBERS_4A' in url and any(b in url for b in ['BAND13.tif', 'BAND15.tif', 'BAND16.tif']):
            Cbers4A_urls.append(url)
        elif 'CBERS_4' in url and any(b in url for b in ['BAND13.tif', 'BAND15.tif', 'BAND16.tif']):
            Cbers4_urls.append(url)

    if Amazonia1_urls:
        log_widget.append(f"📥 Iniciando download de imagens Amazonia-1...")
        log_message(f" ", log_widget)        
        QApplication.processEvents() # Atualiza painel de mensagens com as informações acima
        #Chama função de download
        download_from_urls_list(Amazonia1_urls, output_dir, "Amazonia-1", log_widget)

    if Cbers4A_urls:
        log_widget.append(f"📥 Iniciando download de imagens CBERS-4A...")
        log_message(f" ", log_widget)        
        QApplication.processEvents()# Atualiza painel de mensagens com as informações acima
        #Chama função de download
        download_from_urls_list(Cbers4A_urls, output_dir, "CBERS-4A", log_widget)

    if Cbers4_urls:
        log_widget.append(f"📥 Iniciando download de imagens CBERS-4...")
        log_message(f" ", log_widget)        
        QApplication.processEvents()# Atualiza painel de mensagens com as informações acima
        #Chama função de download
        download_from_urls_list(Cbers4_urls, output_dir, "CBERS-4", log_widget)



# Função download_from_urls_list() (adaptada para a ABA 2):
def download_from_urls_list(urls, output_dir, satelite, log_widget=None):
    rgb_created2 = False
    # Define pares de bandas RGB por satélite
    bandas_rgb = {
        "Amazonia-1": ("BAND4", "BAND3", "BAND2"),
        "CBERS-4A": ("BAND16", "BAND15", "BAND13"),
        "CBERS-4": ("BAND16", "BAND15", "BAND13")
    }

    # Agrupa URLs por cena (prefixo comum até _BANDxx)
    grupos = {} # cria lista vazia para montar os grupos de imagens 
    for url in urls:
        base = url.split("_BAND")[0]
        if base not in grupos:
            grupos[base] = []
        grupos[base].append(url)

    for base, url_list in grupos.items():
        bandas = bandas_rgb.get(satelite)
        if not bandas:
            if log_widget: log_widget.append(f"❌ Satélite não reconhecido: {satelite}")
            continue

        arquivos_banda = {}
        buffers_banda = {}
        for url in url_list:
            for banda in bandas:
                if banda in url:
                    try:
                        # Download para memória
                        response = urllib.request.urlopen(url)# faz a requisição no servidor
                        buffer = BytesIO(response.read()) #salvando 3 bandas em memoria
                        buffers_banda[banda] = buffer
                        if log_widget: log_widget.append(f"⬇️ Baixado (memória):{os.path.basename(url).split('?')[0]}")
                        QApplication.processEvents()# Atualiza painel de mensagens com as informações acima
                    except Exception as e:
                        if log_widget: log_widget.append(f"❌ Erro ao baixar {url}: {e}")

        if len(buffers_banda) == 3:
            try:
                # Criar arquivos TIF temporários em /vsimem
                vsimem_paths = {}
                for i, banda in enumerate(bandas, start=1):
                    vsimem_path = f"/vsimem/{base}_B{i}.tif"
                    gdal.FileFromMemBuffer(vsimem_path, buffers_banda[banda].getvalue())
                    vsimem_paths[banda] = vsimem_path

                # Abrir as bandas e ler arrays
                r = gdal.Open(vsimem_paths[bandas[0]]).ReadAsArray()
                g = gdal.Open(vsimem_paths[bandas[1]]).ReadAsArray()
                b = gdal.Open(vsimem_paths[bandas[2]]).ReadAsArray()

                # Normalização simples para 8 bits
                def normalizar(banda):
                    return ((banda - banda.min()) / (banda.max() - banda.min()) * 255).astype('uint8')

                r8 = normalizar(r)
                g8 = normalizar(g)
                b8 = normalizar(b)

                # Criar RGB composto
                driver = gdal.GetDriverByName('GTiff')
                
                # Ajuste do nome do arquivo
                nome_base = os.path.basename(base)

                # 1. Trocar AMAZONIA_1 por AMAZONIA-1
                # Padroniza nome do satélite com hífen
                substituicoes = {
                    "AMAZONIA_1": "AMAZONIA-1",
                    "CBERS_4": "CBERS-4",
                    "CBERS_4A": "CBERS-4A"
                }
                for original, novo in substituicoes.items():
                    if original in nome_base:
                        nome_base = nome_base.replace(original, novo)
                        break  # Só um satélite será encontrado

                # 2. Reorganizar campos de data e órbita-ponto
                # Supondo padrão: AMAZONIA-1_WFI_20250504_037_014_L4_LEFT
                partes = nome_base.split("_")
                if len(partes) >= 6 and partes[2].isdigit() and len(partes[2]) == 8:
                    data = partes[2]
                    data_formatada = data[6:] + data[4:6] + data[0:4]  # 04052025
                    # Nova lista contendo apenas os 5 primeiros campos reorganizados
                    # Ex: [SATELITE, WFI, ORBITA, PONTO, DATA]
                    partes_reorganizadas = [partes[0], partes[1], partes[3], partes[4], data_formatada]
                    nome_base = "_".join(partes_reorganizadas)

                # Detectar o satélite já padronizado no nome_base
                sat_padronizado = None
                for s in ["AMAZONIA-1", "CBERS-4", "CBERS-4A"]:
                    if s in nome_base:
                        sat_padronizado = s
                        break
                # Define o sufixo conforme o satélite
                sufixos = {
                    "AMAZONIA-1": "_8bits_432",
                    "CBERS-4": "_8bits_161513",
                    "CBERS-4A": "_8bits_161513"
                }
                sufixo = sufixos.get(sat_padronizado, "_8bits_RGB.tif")  # fallback caso algo inesperado

                # Caminho final com novo sufixo
                output_path = os.path.join(output_dir, nome_base + sufixo)
                filename2 = nome_base + sufixo
                            
                
                out_ds = driver.Create(output_path, r.shape[1], r.shape[0], 3, gdal.GDT_Byte)
                out_ds.GetRasterBand(1).WriteArray(r8)
                out_ds.GetRasterBand(2).WriteArray(g8)
                out_ds.GetRasterBand(3).WriteArray(b8)

                # Copia projeção e geotransform da primeira banda
                ref_ds = gdal.Open(vsimem_paths[bandas[0]])
                out_ds.SetProjection(ref_ds.GetProjection())
                out_ds.SetGeoTransform(ref_ds.GetGeoTransform())
                out_ds.FlushCache()
                out_ds = None
                rgb_created2 = True

                if log_widget:
                    log_widget.append(f"✅ Composição RGB salva: {filename2}")
                    log_message(f" ", log_widget)        
                    QApplication.processEvents()#Atualiza painel de Informações
                    
                # Adiciona ao QGIS
                    raster_layer = QgsRasterLayer(output_path, os.path.basename(output_path))  # Cria uma camada raster no QGIS
                    QgsProject.instance().addMapLayer(raster_layer)

                # Limpa os arquivos temporários
                for path in vsimem_paths.values():
                    gdal.Unlink(path)

            except Exception as e:
                if log_widget: log_widget.append(f"❌ Erro na criação da composição RGB: {e}")
                log_message(f" ", log_widget)        
                QApplication.processEvents()#Atualiza painel de Informações caso ocorra
        else:
            if log_widget:
                log_widget.append(f"⚠️ Banda(s) ausente(s) em: {base}")

    # Após o loop principal que percorre os grupos:
    if log_widget:
        if rgb_created2:
            log_message(f"💾 Todas as composições RGB foram criadas com sucesso!", log_widget)
        else:
            log_message(f"⚠️ Nenhuma composição RGB foi criada a partir da lista de URLs.", log_widget)


#--------------------------------- FIM DO PROCESSAMENTO DA ABA 2---------------------------------------

# Para executar no console do QGIS:
# DESCOMENTAR EXIBIR INTERFACE ABAIXO
#dlg.show()


#--------------------------------- PARTE ESPECIFICA PARA PLUGIN---------------------------------------



class DeterCerradoPlugin:
    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon_cerrado.png")
        self.action = QAction(QIcon(icon_path), "Gerar Imagens DETER Cerrado", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("BIOMASBR_CERRADO", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("BIOMASBR_CERRADO", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        from .main_plugin import create_interface
        self.widget = create_interface()
        self.widget.show()




