# Importação de Bibliotecas
from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QLabel, QDateEdit, QPushButton, QTextEdit, QComboBox, QFileDialog, QApplication
from qgis.core import QgsRasterLayer, QgsProject, QgsRasterShader, QgsColorRampShader, QgsSingleBandPseudoColorRenderer
from PyQt5.QtCore import QDate
import requests
import os
import re
import processing
from osgeo import gdal  
import numpy as np  
from io import BytesIO  


# INTERFACE QGIS
def create_interface():
    widget = QWidget()
    widget.setWindowTitle("DETER_CERRADO - By Garga")  # Define o título da janela
    widget.resize(500, 400)  # Aumenta o tamanho da janela
    layout = QVBoxLayout()
    
    label = QLabel("Selecione a Data da Imagem:")
    layout.addWidget(label)
    
    date_edit = QDateEdit()
    date_edit.setCalendarPopup(True)
    date_edit.setDate(QDate.currentDate())
    layout.addWidget(date_edit)
    
    satellite_selector = QComboBox()
    satellite_selector.addItems(["Amazonia-1", "CBERS-4A", "CBERS-4"])
    layout.addWidget(satellite_selector)
    
    log_widget = QTextEdit()
    log_widget.setReadOnly(True)
    layout.addWidget(log_widget)
    
    destination_folder = [os.path.expanduser("~/Downloads/DETER_CERRADO")]
    log_widget.append(f"Pasta de Destino Padrão  >>  Downloads\DETER_CERRADO")

    btn_select_folder = QPushButton("Selecionar Pasta de Destino")
    btn_select_folder.clicked.connect(lambda: select_folder(destination_folder, log_widget))
    layout.addWidget(btn_select_folder)
    
    btn_download = QPushButton("Baixar Imagens")
    btn_download.clicked.connect(lambda: process_date(date_edit.date(), satellite_selector.currentText(), log_widget, destination_folder[0]))
    layout.addWidget(btn_download)
      
    widget.setLayout(layout)
    widget.show()
    return widget
    
    
# SELEÇÃO FOLDER DESTINO
def select_folder(destination_folder, log_widget):
    folder = QFileDialog.getExistingDirectory(None, "Selecione a pasta de destino", os.path.expanduser("~"))
    if folder:
        log_widget.clear()  # Limpa o conteúdo anterior
        destination_folder[0] = folder
        log_widget.append(f"Nova Pasta de Destino:\n {folder}")
        

# EXIBIR
dlg = create_interface()


# LOGS NO CONSOLE
def log_message(message, log_widget):
    log_widget.append(message)
    print(message)
    

# VERIFICAR ORBIAS/PONTOS DO CERRADO
def is_valid_orbit_point(orbit_point, satellite):
    valid_ranges = {
        "Amazonia-1": [
            (34, 16, 34, 19), (35, 15, 35, 19), (36, 16, 36, 19),
            (37, 17, 37, 18), (38, 17, 38, 17)
        ],
        "CBERS-4A": [
            (209, 116, 209, 148), (215, 124, 215, 140), (221, 132, 221, 140),
            (196, 132, 196, 140), (202, 116, 202, 148), (208, 116, 208, 140),
            (214, 124, 214, 140), (220, 132, 220, 140), (195, 132, 195, 140),
            (226, 124, 226, 140), (201, 116, 201, 148), (207, 116, 207, 148),
            (213, 116, 213, 140), (219, 132, 219, 140), (225, 124, 225, 132),
            (200, 116, 200, 140), (206, 116, 206, 148), (212, 116, 212, 140),
            (218, 132, 218, 140), (224, 124, 224, 132), (199, 116, 199, 140),
            (205, 116, 205, 148), (211, 116, 211, 140), (217, 132, 217, 140),
            (223, 132, 223, 132), (198, 116, 198, 140), (204, 116, 204, 148),
            (210, 116, 210, 140), (216, 124, 216, 140), (222, 124, 222, 132),
            (197, 116, 197, 140), (203, 116, 203, 148)
        ],
        "CBERS-4": [
    (156, 105, 156, 129), (173, 111, 173, 117), (164, 105, 164, 123),
    (155, 105, 155, 129), (172, 111, 172, 117), (163, 105, 163, 123),
    (154, 105, 154, 129), (171, 111, 171, 117), (162, 105, 162, 129),
    (153, 105, 153, 129), (170, 111, 170, 123), (161, 105, 161, 129),
    (152, 105, 152, 129), (169, 111, 169, 123), (160, 105, 160, 129),
    (151, 105, 151, 123), (168, 111, 168, 123), (159, 105, 159, 129),
    (150, 111, 150, 123), (167, 111, 167, 123), (158, 105, 158, 129),
    (149, 117, 149, 123), (175, 111, 175, 117), (166, 111, 166, 123),
    (157, 105, 157, 129), (174, 111, 174, 117), (148, 117, 148, 123),
    (165, 111, 165, 123)
        ]
    }
    match = re.match(r"(\d{3})_(\d{3})", orbit_point)
    if match:
        orbit, point = int(match.group(1)), int(match.group(2))
        return any(o_min <= orbit <= o_max and p_min <= point <= p_max for o_min, p_min, o_max, p_max in valid_ranges[satellite])
    return False
    

# CRIAÇÃO DA LISTA DE URLS PARA DOWNLOAD
def process_date(date, satellite, log_widget, save_dir):
    
    log_message(f"Cenas do Bioma Cerrado para Data/Sensor Selecionados:", log_widget)
    QApplication.processEvents()
    
    
    # Lista de URLs base dos arquivos a serem baixados
        
    base_urls = {
        "Amazonia-1": "http://cbers9.dpi.inpe.br:8089/files/AMAZONIA1",
        "CBERS-4A": "http://cbers9.dpi.inpe.br:8089/files/CBERS4A",
        "CBERS-4": "http://cbers9.dpi.inpe.br:8089/files/CBERS4"
    }
    bands = {
        "Amazonia-1": ["L4_BAND2", "L4_BAND3", "L4_BAND4", "L4_LEFT_BAND2", "L4_LEFT_BAND3", "L4_LEFT_BAND4"],
        "CBERS-4A": ["L4_BAND13", "L4_BAND15", "L4_BAND16", "L4_LEFT_BAND13", "L4_LEFT_BAND15", "L4_LEFT_BAND16"],
        "CBERS-4": ["L4_BAND13", "L4_BAND15", "L4_BAND16", "L4_LEFT_BAND13", "L4_LEFT_BAND15", "L4_LEFT_BAND16" ]
    }
    
    year_month = date.toString("yyyy_MM")
    day = date.toString("yyyy_MM_dd")
    day_tif = date.toString("yyyyMMdd")
    day_tif_save = date.toString("ddMMyyyy")
    os.makedirs(save_dir, exist_ok=True)
    
    date_url = f"{base_urls[satellite]}/{year_month}/"
    response = requests.get(date_url)
    if response.status_code != 200:
        log_message("Erro: Diretório da data não encontrado.", log_widget)
        QApplication.processEvents()
        return
    scene_dirs = re.findall(rf"({satellite.upper().replace('-', '_')}_(?:WFI_RAW|AWFI_DRD)_{day}\.\d{{2}}_\d{{2}}_\d{{2}}_[A-Z0-9]+)/", response.text)


    if not scene_dirs:
        log_message("Erro: Nenhuma cena encontrada para esta data.", log_widget)
        QApplication.processEvents()
        return
    
    urls_orbitas_pontos = []
    processed_orbits = set()
    for scene in scene_dirs:
        scene_url = f"{date_url}{scene}/"
        response_scene = requests.get(scene_url)
        if response_scene.status_code != 200:
            log_message(f"Erro: Diretório da cena {scene} não encontrado.", log_widget)
            QApplication.processEvents()
            continue

        orbit_dirs = re.findall(r"(\d{3}_\d{3}_0)/", response_scene.text)
        if not orbit_dirs:
            log_message(f"Erro: Nenhuma órbita-ponto encontrada na cena {scene}.", log_widget)
            QApplication.processEvents()
            continue
        
        for orbit_point in orbit_dirs:
            if orbit_point in processed_orbits or not is_valid_orbit_point(orbit_point, satellite):
                continue
            processed_orbits.add(orbit_point)
            
            log_message(f"Satélite {satellite} : {'_'.join(orbit_point.split('_')[:2])}", log_widget)
            QApplication.processEvents()
            projection_folder = "4_BC_LCC_WGS84" if satellite == "Amazonia-1" else "4_BC_UTM_WGS84"
            
            bands_url = f"{scene_url}{orbit_point}/{projection_folder}/"
            sensor = "WFI" if satellite in ["Amazonia-1", "CBERS-4A"] else "AWFI"
            filename = f"{satellite.upper().replace('-', '_')}_{sensor}_{day_tif}_{orbit_point[:7]}"
            urls_orbitas_pontos.append(f"{bands_url}{filename}")
          
    log_message("Iniciando download e geração de RGB...", log_widget)
    QApplication.processEvents()
    
    download_and_create_rgb(urls_orbitas_pontos, save_dir, satellite, log_widget)
    

# Função para tentar baixar uma banda, testando dois sufixos
def tentar_baixar_banda(url_base, sufixo1, sufixo2):
    url_tentativa1 = f"{url_base}_{sufixo1}.tif"
    url_tentativa2 = f"{url_base}_{sufixo2}.tif"
    
    conteudo = download_file_to_memory(url_tentativa1)
    if conteudo:
        return conteudo
    else:
        return download_file_to_memory(url_tentativa2)


# Função principal para baixar as bandas e criar a composição RGB
def download_and_create_rgb(urls, destination_folder, satellite, log_widget):
    
    for url_base in urls:
        base_name = url_base.split('/')[-1]  # Obtém o nome base da URL (AMAZONIA_1_WFI_20250408_034_019)
        
        parts = base_name.split('_')
        satellite_raw = parts[0] + "_" + parts[1]  # ex: 'AMAZONIA_1', 'CBERS_4', 'CBERS_4A'
        satelname = satellite_raw.replace('_', '-')  # ex: 'AMAZONIA-1', 'CBERS-4', 'CBERS-4A'
        sensor = parts[2]  # 'WFI' ou 'AWFI'
        date_str = parts[3]  # '20250406'
        orbit = parts[4]
        point = parts[5]
        formatted_date = f"{date_str[6:8]}{date_str[4:6]}{date_str[0:4]}"
        base_name2 = f"{satelname}_{sensor}_{orbit}_{point}_{formatted_date}"
        
            
        if satellite == "Amazonia-1": 
            sufixo = "8bits_342"
            band1_mem = tentar_baixar_banda(url_base, "L4_BAND3", "L4_LEFT_BAND3")
            band2_mem = tentar_baixar_banda(url_base, "L4_BAND4", "L4_LEFT_BAND4")
            band3_mem = tentar_baixar_banda(url_base, "L4_BAND2", "L4_LEFT_BAND2")
        else:
            sufixo = "8bits_151613"
            band1_mem = tentar_baixar_banda(url_base, "L4_BAND15", "L4_LEFT_BAND15")
            band2_mem = tentar_baixar_banda(url_base, "L4_BAND16", "L4_LEFT_BAND16")
            band3_mem = tentar_baixar_banda(url_base, "L4_BAND13", "L4_LEFT_BAND13")
             
                
        # Verifica se todas as bandas foram baixadas com sucesso
        if band1_mem and band2_mem and band3_mem:
            
            # Converte os dados em memória para um VRT no sistema de arquivos virtual do GDAL
            band1_vsimem = f"/vsimem/{base_name2}_B1.tif"
            band2_vsimem = f"/vsimem/{base_name2}_B2.tif"
            band3_vsimem = f"/vsimem/{base_name2}_B3.tif"

            # Escreve as bandas temporárias em vsimem (memória virtual do GDAL)
            gdal.FileFromMemBuffer(band1_vsimem, band1_mem.getvalue())
            gdal.FileFromMemBuffer(band2_vsimem, band2_mem.getvalue())
            gdal.FileFromMemBuffer(band3_vsimem, band3_mem.getvalue())

            # Abre as bandas a partir da memória virtual
            band1 = gdal.Open(band1_vsimem)
            band2 = gdal.Open(band2_vsimem)
            band3 = gdal.Open(band3_vsimem)

            # Lê os dados das bandas como arrays
            band1_data = band1.GetRasterBand(1).ReadAsArray()
            band2_data = band2.GetRasterBand(1).ReadAsArray()
            band3_data = band3.GetRasterBand(1).ReadAsArray()


# Cria a composição RGB diretamente

            rgb_output = os.path.join(destination_folder, f"{base_name2}_{sufixo}.tif")  # Define o caminho do arquivo de saída       
            rgb_composition = create_rgb_composition_in_memory(
                band1_data, band2_data, band3_data, rgb_output, 
                band1.GetProjection(), band1.GetGeoTransform()
            )
            
            if rgb_composition:
                log_message(f"✅ Finalizado com Sucesso: {base_name2}_{sufixo}.tif", log_widget)
                QApplication.processEvents()
                
                raster_layer = QgsRasterLayer(rgb_composition, f"{base_name2}_{sufixo}")  # Cria uma camada raster no QGIS

                if not raster_layer.isValid():
                    log_message(f"Erro ao carregar a composição RGB: {base_name2}_{sufixo}.tif", log_widget)
                    QApplication.processEvents()
                else:
                    QgsProject.instance().addMapLayer(raster_layer)  # Adiciona a camada ao projeto QGIS
                    
            else:
                log_message(f"Erro ao criar a composição RGB: {base_name2}_{sufixo}.tif", log_widget)
                QApplication.processEvents()

            # Remove os arquivos temporários da memória virtual
            gdal.Unlink(band1_vsimem)
            gdal.Unlink(band2_vsimem)
            gdal.Unlink(band3_vsimem)
        else:
            log_message(f"❌ Pasta Vazia para: {base_name2}_{sufixo}.tif", log_widget)
            QApplication.processEvents()


# Função para baixar um arquivo de uma URL e retorná-lo como BytesIO (dados em memória)
def download_file_to_memory(url):
    try:
        # Faz uma requisição GET para a URL
        with requests.get(url, stream=True) as r:
            r.raise_for_status()  # Levanta uma exceção se a requisição falhar
            return BytesIO(r.content)  # Retorna o conteúdo do arquivo em memória
    except requests.exceptions.RequestException as e:
        
        return None  # Retorna None se houver um erro

# Função para normalizar um array para 8 bits
def normalize_to_8bit(array):
    array_min = np.min(array)  # Obtém o valor mínimo do array
    array_max = np.max(array)  # Obtém o valor máximo do array
    normalized = ((array - array_min) / (array_max - array_min)) * 255  # Normaliza o array para a faixa 0-255
    return normalized.astype(np.uint8)  # Converte o array normalizado para tipo uint8

# Função para criar uma composição RGB a partir de três bandas em memória
def create_rgb_composition_in_memory(band1_data, band2_data, band3_data, output_path, projection, geotransform):
    try:
        # Cria um novo arquivo GeoTIFF para a composição RGB
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, band1_data.shape[1], band1_data.shape[0], 3, gdal.GDT_Byte)
        
        # Define a projeção e a transformação geoespacial do novo arquivo
        out_ds.SetProjection(projection)
        out_ds.SetGeoTransform(geotransform)
        
        # Escreve os arrays normalizados para o novo arquivo
        out_ds.GetRasterBand(1).WriteArray(normalize_to_8bit(band1_data))
        out_ds.GetRasterBand(2).WriteArray(normalize_to_8bit(band2_data))
        out_ds.GetRasterBand(3).WriteArray(normalize_to_8bit(band3_data))
        
        out_ds.FlushCache()  # Garante que todos os dados sejam escritos no disco
        out_ds = None  # Fecha o arquivo
        
        return output_path  # Retorna o caminho do arquivo de saída
    except Exception as e:
        print(f"Erro ao criar a composição RGB: {e}")  # Imprime o erro se a criação falhar
        return None  # Retorna None se houver um erro



