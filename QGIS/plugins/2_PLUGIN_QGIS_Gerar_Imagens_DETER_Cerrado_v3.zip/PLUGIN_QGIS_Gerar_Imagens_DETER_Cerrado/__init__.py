def classFactory(iface):
    from .main_plugin import DeterCerradoPlugin
    return DeterCerradoPlugin(iface)
