# Downloader Imagens DETER Cerrado.py

import sys
import os
import zipfile
import urllib.parse
import requests
import re

from datetime import datetime


from qgis.PyQt.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QListWidget, QListWidgetItem,
    QFileDialog, QMessageBox, QProgressDialog, QComboBox
)

from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QPixmap, QImage, QIcon

from qgis.core import QgsRasterLayer, QgsProject

from osgeo import gdal
import numpy as np


BASE_URL = "https://terrabrasilis.dpi.inpe.br/rawdata/BIOMAS_BR/CERRADO/IMAGENS/DETER"


PLUGIN_DIR = os.path.dirname(__file__)

def resource_path(relative_path):
    return os.path.join(PLUGIN_DIR, relative_path)




# --------------------------------------------------------
# THREAD DOWNLOAD
# --------------------------------------------------------
class DownloadWorker(QThread):

    progress = pyqtSignal(int)
    message = pyqtSignal(str)
    finished = pyqtSignal(int)

    def __init__(self, items, output_folder, tif_list):
        super().__init__()
        self.items = items
        self.output_folder = output_folder
        self.tif_list = tif_list        
        self._cancel = False



    def run(self):

        os.makedirs(self.output_folder, exist_ok=True)
        total = len(self.items)
        baixados = 0

        for ano, mes, url in self.items:

            if self._cancel:
                self.message.emit("Download cancelado pelo usuário.")
                break

            nome = os.path.basename(url)
            destino = os.path.join(self.output_folder, nome)

            try:

                self.message.emit(f"Baixando {nome}")

                with requests.get(url, stream=True, timeout=120) as r:
                    r.raise_for_status()

                    with open(destino, "wb") as f:
                        for chunk in r.iter_content(8192):
                            if chunk:
                                f.write(chunk)

                with zipfile.ZipFile(destino) as z:
                    for n in z.namelist():
                        if n.lower().endswith(".tif"):
                            z.extract(n, self.output_folder)
                            tif_path = os.path.join(self.output_folder, n)
                            self.tif_list.append(tif_path)



                os.remove(destino)

                baixados += 1
                self.message.emit(f"✅ ({baixados}/{total}) Baixado: {destino}")
                self.progress.emit(baixados)

            except Exception as e:
                self.message.emit(str(e))

        self.finished.emit(baixados)
        path_corrigido = self.output_folder.replace("\\", "/")
        self.message.emit(f"✅ Todos os downloads e extrações concluídos em:\n{path_corrigido}")

    def cancel(self):
        self._cancel = True


# --------------------------------------------------------
# INTERFACE
# --------------------------------------------------------
class DeterDownloader(QWidget):

    def __init__(self):
        super().__init__()

        icon_path = resource_path("icone_deter150.png")
        self.setWindowIcon(QIcon(icon_path))

        self.setWindowTitle("Downloader Imagens DETER Cerrado")
        self.resize(900, 650)

        self.output_folder = os.path.expanduser("~/Downloads/DETER")

    # Estilos visuais (tema verde)
        self.setStyleSheet("""
            QWidget { background-color: #f6fbf6; font-family: Segoe UI; }
            QLabel { font-size: 13px; color: #1b5e20; }
            QPushButton { background-color: #2e7d32; color: white; border-radius: 6px; padding: 6px; }
            QPushButton:hover { background-color: #1b5e20; }
            QLineEdit { padding: 6px; border: 1px solid #cfd8dc; border-radius: 4px; }
            QListWidget { background-color: #ffffff; border: 1px solid #cfd8dc; }
            QComboBox { padding: 6px; }
        """)

        layout = QVBoxLayout()

        title = QLabel("🧩 Desenvolvido por Gargamel")
        title.setStyleSheet("font-size: 12px; font-weight: bold; color: #0b6623;")
        layout.addWidget(title)

        # ---------------------------------------------------
        # ÓRBITA
        # ---------------------------------------------------
        linha_orbita = QHBoxLayout()
        linha_orbita.addWidget(QLabel(
            "Órbita:\n"
            "Ex: 035 → todas cenas da órbita\n"
            "Ex: 035_017 → órbita-ponto específica\n"
            "Vazio → todas (AMZ1, CBERS-4, CBERS-4A)"
        ))

        self.tile_edit = QLineEdit()
        linha_orbita.addWidget(self.tile_edit)

        linha_orbita.addWidget(QLabel("Ano"))

        self.ano_edit = QLineEdit(str(datetime.now().year))
        linha_orbita.addWidget(self.ano_edit)

        layout.addLayout(linha_orbita)

        # ---------------------------------------------------
        # MESES
        # ---------------------------------------------------
        meses = [
            "janeiro", "fevereiro", "marco", "abril",
            "maio", "junho", "julho", "agosto",
            "setembro", "outubro", "novembro", "dezembro"
        ]

        linha_mes = QHBoxLayout()

        linha_mes.addWidget(QLabel("Mês 1"))

        self.mes1 = QComboBox()
        self.mes1.addItems(meses)
        mes_atual = datetime.now().month
        self.mes1.setCurrentIndex(mes_atual - 1)
        linha_mes.addWidget(self.mes1)

        linha_mes.addWidget(QLabel("Mês 2"))

        self.mes2 = QComboBox()
        self.mes2.addItems(meses)
        linha_mes.addWidget(self.mes2)

        layout.addLayout(linha_mes)        

        # conectar evento
        self.mes1.currentIndexChanged.connect(self.atualizar_mes2)
        # inicializar mês 2
        self.atualizar_mes2()


        # ---------------------------------------------------
        # BOTÃO PESQUISA
        # ---------------------------------------------------
        self.search_btn = QPushButton("🔍 Pesquisar no servidor")
        self.search_btn.clicked.connect(self.search_files)
        layout.addWidget(self.search_btn)

        # ---------------------------------------------------
        # LISTAS
        # ---------------------------------------------------
        listas = QHBoxLayout()

        self.lista_mes1 = QListWidget()
        self.lista_mes1.itemClicked.connect(self.preview_mes1)

        self.lista_mes2 = QListWidget()
        self.lista_mes2.itemClicked.connect(self.preview_mes2)

        listas.addWidget(self.lista_mes1)
        listas.addWidget(self.lista_mes2)

        layout.addLayout(listas)

        # ---------------------------------------------------
        # PREVIEWS
        # ---------------------------------------------------
        previews = QHBoxLayout()

        self.preview1 = QLabel("Preview Mês 1")
        self.preview1.setAlignment(Qt.AlignCenter)
        self.preview1.setMinimumHeight(250)

        self.preview2 = QLabel("Preview Mês 2")
        self.preview2.setAlignment(Qt.AlignCenter)
        self.preview2.setMinimumHeight(250)

        previews.addWidget(self.preview1)
        previews.addWidget(self.preview2)

        layout.addLayout(previews)

        # ---------------------------------------------------
        # BOTÕES
        # ---------------------------------------------------
        botoes = QHBoxLayout()

        self.output_btn = QPushButton("📁 Alterar pasta de destino")
        self.output_btn.clicked.connect(self.select_output)

        self.download_btn = QPushButton("⬇ Baixar e Extrair selecionados")
        self.download_btn.clicked.connect(self.download_selected)

        botoes.addWidget(self.output_btn)
        botoes.addWidget(self.download_btn)

        layout.addLayout(botoes)

        self.status_label = QLabel("")
        layout.addWidget(self.status_label)

        self.setLayout(layout)

    # Prepara variáveis internas (progress_dialog, worker)
        self._download_worker = None
        self._progress_dialog = None
        self.downloaded_tifs = []

    def atualizar_mes2(self):

        mes1_index = self.mes1.currentIndex()

        if mes1_index == 0:  # janeiro
            mes2_index = 11  # dezembro
        else:
            mes2_index = mes1_index - 1

        self.mes2.setCurrentIndex(mes2_index)        

    # ---------------------------------------------------
    # BUSCA
    # ---------------------------------------------------
    def search_files(self):

        self.preview1.clear()
        self.preview2.clear()

        self.preview1.setText("Preview Mês 1")
        self.preview2.setText("Preview Mês 2")
        
        orb = self.tile_edit.text().strip()

        # Se vazio → sem filtro
        if not orb:
            orb = None

        # valida somente se tiver valor
        if orb is not None:

            if len(orb) == 3 and orb.isdigit():
                orb = "_" + orb + "_"

            elif len(orb) == 7 and orb[3] == "_":
                orb = "_" + orb + "_"

            else:
                QMessageBox.warning(
                    self,
                    "Aviso",
                    "Formato inválido.\n\nUse:\n"
                    "035  → todas cenas da órbita\n"
                    "035_017  → órbita-ponto específica\n\n"
                    "Ou deixe vazio para listar tudo"
                )
                return



        texto_ano = self.ano_edit.text().strip()

        if not texto_ano.isdigit() or len(texto_ano) != 4:
            QMessageBox.warning(
                self,
                "Ano inválido",
                "Digite um ano válido com 4 dígitos.\nExemplo: 2026"
            )
            return

        ano = int(texto_ano)

        mes1_index = self.mes1.currentIndex()
        mes2_index = self.mes2.currentIndex()

        mes1 = self.mes1.currentText()
        mes2 = self.mes2.currentText()

        ano_mes2 = ano

        # tratar virada de ano
        if mes1_index == 0:  # janeiro
            ano_mes2 = ano - 1

        self.buscar_mes(self.lista_mes1, ano, mes1, orb)
        self.buscar_mes(self.lista_mes2, ano_mes2, mes2, orb)

    def buscar_mes(self, lista, ano, mes, orb):

        lista.clear()

        base_url = f"{BASE_URL}/{ano}/{mes}/"

        try:

            resp = requests.get(base_url, timeout=15)

            if resp.status_code == 404:
                QMessageBox.information(
                    self,
                    "Diretório inexistente",
                    f"Nenhum diretório encontrado para {mes}/{ano}.\nProvavelmente as imagens ainda não foram publicadas."
                )
                return

            resp.raise_for_status()

            html = resp.text

            # encontra todos os arquivos zip no listing do servidor
            arquivos = re.findall(r'href="([^"]+\.zip)"', html, re.IGNORECASE)

            resultados = []

            for href in arquivos:

                url = urllib.parse.urljoin(base_url, href)
                name = os.path.basename(urllib.parse.urlparse(url).path)

                if orb is None or orb in name:

                    partes = name.replace(".zip", "").split("_")

                    try:
                        data_str = partes[4]  # 5º elemento → DDMMYYYY
                        data_dt = datetime.strptime(data_str, "%d%m%Y")
                    except:
                        data_dt = datetime(1900, 1, 1)  # fallback (vai pro final)

                    resultados.append((data_dt, name, url))
                    
            # ordenar por data (mais recente primeiro)
            resultados.sort(reverse=True)
            for data_dt, name, url in resultados:

                item = QListWidgetItem(name)
                item.setData(Qt.UserRole, (ano, mes, url))
                item.setCheckState(Qt.Unchecked)

                lista.addItem(item)            
        except Exception as e:

            QMessageBox.critical(
                self,
                "Erro de conexão",
                f"Falha ao acessar {base_url}:\n{e}"
            )

    # ---------------------------------------------------
    # PREVIEW
    # ---------------------------------------------------
    def carregar_preview(self, label, item):

        ano, mes, url = item.data(Qt.UserRole)

        zip_name = os.path.basename(url)

        jpg = zip_name.replace(".zip", ".jpg")

        vsi = f"/vsizip//vsicurl/{url}/{jpg}"

        try:

            ds = gdal.Open(vsi)

            if ds is None:
                label.setText("Preview não encontrado")
                return

            arr = ds.ReadAsArray()

            if len(arr.shape) == 3:

                rgb = np.dstack((arr[0], arr[1], arr[2])).astype("uint8")

            else:

                rgb = np.stack((arr, arr, arr), axis=-1).astype("uint8")

            h, w, ch = rgb.shape

            qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)

            pix = QPixmap.fromImage(qimg)

            pix = pix.scaled(
                label.width(),
                label.height(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )

            label.setPixmap(pix)

        except Exception as e:
            label.setText(str(e))

    def preview_mes1(self, item):
        self.carregar_preview(self.preview1, item)

    def preview_mes2(self, item):
        self.carregar_preview(self.preview2, item)

    # ---------------------------------------------------
    # DOWNLOAD
    # ---------------------------------------------------
    def download_selected(self):

        # limpar lista de downloads anteriores
        self.downloaded_tifs = []        
        selected = []

        for lista in [self.lista_mes1, self.lista_mes2]:

            for i in range(lista.count()):

                item = lista.item(i)

                if item.checkState() == Qt.Checked:
                    selected.append(item.data(Qt.UserRole))

        if not selected:
            QMessageBox.warning(self, "Aviso", "Nada selecionado")
            return

        # Cria janela de progresso (QProgressDialog)
        total = len(selected)
        self._progress_dialog = QProgressDialog("Preparando downloads...", "Cancelar", 0, total, self)
        self._progress_dialog.setWindowTitle("Baixando")
        self._progress_dialog.setWindowModality(Qt.WindowModal)
        self._progress_dialog.setMinimumDuration(0)
        self._progress_dialog.show()
        
        # Ajuste da largura da janela para garantir que o título caiba
        self._progress_dialog.setFixedWidth(300)  # Ajuste o valor conforme necessário
        self._progress_dialog.setValue(0)

        # Inicia a thread DownloadWorker
        self._download_worker = DownloadWorker(selected, self.output_folder, self.downloaded_tifs)
        # Conecta sinais da thread aos métodos da UI
        self._download_worker.progress.connect(self._progress_dialog.setValue)
        self._download_worker.message.connect(self._set_status)
        self._download_worker.finished.connect(self._download_finished)
        self._progress_dialog.canceled.connect(self._download_worker.cancel)
        # Inicia downloads em paralelo
        self._download_worker.start()


    #Atualizar mensagens de status:         
    def _set_status(self, text):
        self.status_label.setText(text)  # Atualiza label inferior
        QApplication.processEvents() # Força refresh da GUI

    
    #Ações após finalizar o download:
    #Fecha diálogo de progresso,  Mostra resumo dos arquivos baixados e Atualiza status para “Pronto.”
    def _download_finished(self, total_baixados):

        if self._progress_dialog:
            self._progress_dialog.close()

        if total_baixados > 0:

            QMessageBox.information(
                self,
                "Concluído",
                f"Download finalizado!\n{total_baixados} arquivo(s) salvo(s)"
            )

            # -----------------------------------
            # localizar ou criar grupo no QGIS
            # -----------------------------------
            root = QgsProject.instance().layerTreeRoot()

            grupo_nome = "IMAGENS_DETER"

            grupo = root.findGroup(grupo_nome)

            if grupo is None:
                grupo = root.addGroup(grupo_nome)

            # -----------------------------------
            # adicionar TIFFs ao grupo
            # -----------------------------------
            for tif in self.downloaded_tifs:

                nome_layer = os.path.basename(tif)

                layer = QgsRasterLayer(tif, nome_layer)

                if layer.isValid():

                    QgsProject.instance().addMapLayer(layer, False)

                    grupo.addLayer(layer)

        else:

            QMessageBox.information(self, "Aviso", "Nenhum arquivo foi baixado.")

        self.status_label.setText("Pronto.")
# ---------- FIM da Classe principal da interface DeterDownloader ----------




        # self.worker = DownloadWorker(selected, self.output_folder)

        # self.worker.message.connect(self.status_label.setText)
        # self.worker.start()

    def select_output(self):

        folder = QFileDialog.getExistingDirectory(self, "Selecionar pasta", self.output_folder)

        if folder:
            self.output_folder = folder

#--------------------------------- FIM---------------------------------------

