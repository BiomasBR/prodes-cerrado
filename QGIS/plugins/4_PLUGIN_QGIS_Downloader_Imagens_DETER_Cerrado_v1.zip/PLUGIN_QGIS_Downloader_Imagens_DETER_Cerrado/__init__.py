def classFactory(iface):
    from .plugin import DeterDownloaderPlugin
    return DeterDownloaderPlugin(iface)
