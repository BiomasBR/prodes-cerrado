from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
import os

from .downloader_dialog import DeterDownloader


class DeterDownloaderPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):

        icon_path = os.path.join(self.plugin_dir, "icone_deter150.png")

        self.action = QAction(
            QIcon(icon_path),
            "Downloader Imagens DETER Cerrado",
            self.iface.mainWindow()
        )

        self.action.triggered.connect(self.run)

        self.iface.addPluginToMenu(
            "BIOMASBR_CERRADO",
            self.action
        )

        self.iface.addToolBarIcon(self.action)

    def unload(self):

        self.iface.removePluginMenu(
            "BIOMASBR_CERRADO",
            self.action
        )

        self.iface.removeToolBarIcon(self.action)

    def run(self):

        self.dlg = DeterDownloader()
        self.dlg.show()