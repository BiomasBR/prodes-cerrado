def classFactory(iface):
    from .main_plugin import ExportPlugin
    return ExportPlugin(iface)
