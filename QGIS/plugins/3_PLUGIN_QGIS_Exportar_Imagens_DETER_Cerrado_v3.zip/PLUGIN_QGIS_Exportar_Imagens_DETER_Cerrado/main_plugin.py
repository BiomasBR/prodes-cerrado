# Exportação de Imagens DETER Cerrado.py
# Plugin QGIS para Exportar as imagens do Grupo QGIS selecionado, gerando arquivos ZIP no final contendo os TIF sem banda alpha
#-----------------------------------------------------------------------------------------------

# Classes Qt	componentes (widgets) usados para montar janelas, botões, campos de texto, etc.
# QWidget	Componente base / janela
# QVBoxLayout	Layout vertical
# QLabel	Texto/imagem
# QDateEdit	Selecionar datas
# QPushButton	Botão
# QTextEdit	Caixa de texto grande
# QComboBox	Menu dropdown
# QFileDialog	Abrir/salvar arquivos
# QApplication	Controla a aplicação
# QTabWidget	Abas
# QLineEdit	Campo de texto simples
# QAction	Ação para menus/atalhos


# Classes PyQGIS 	manipular camadas raster, projetos, renderização e simbolização
# QgsRasterLayer	Carrega e representa um raster no QGIS
# QgsProject	Interface com o projeto QGIS atual (adicionar camadas, salvar, etc.)
# QgsRasterShader	Define regras de coloração para raster
# QgsColorRampShader	Cria gradientes e rampas de cor para raster
# QgsSingleBandPseudoColorRenderer	Aplica o shader e renderiza rasters de banda única




# Importação de Bibliotecas
import os # permite interagir com o sistema operacional.
import zipfile
import requests # usada para fazer requisições HTTP
import traceback # para capturar, formatar e exibir mensagens de erro (stack traces) de forma detalhada

# PyQt > para toda a interface gráfica
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPushButton, QTextEdit, QComboBox,QFileDialog, QApplication, QLineEdit, QCheckBox, QMessageBox, QAction)
from qgis.core import (QgsProject, QgsRasterFileWriter, QgsRasterPipe, QgsLayerTreeGroup, QgsMapLayer)
from qgis.utils import iface

from osgeo import gdal
gdal.SetConfigOption('GDAL_PAM_ENABLED', 'NO')

from qgis.PyQt.QtGui import QIcon
#-----------------------------FIM Importação de Bibliotecas -----------------------------------------------------------------------------------------------------------


#---------------------- INTERFACE principal da aplicação-------------------------------------------
class ExportDialog(QDialog):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Exportação de Imagens DETER Cerrado - By Garga")
        self.adjustSize()  # ajusta ao conteúdo
        self.setMinimumWidth(550)  # largura mínima para não quebrar textos
        self.setMinimumHeight(500)  # altura mínima
        self.resize(self.sizeHint())  # ajusta dinamicamente

        # Centralizar a janela na tela
        frame_gm = self.frameGeometry()
        screen = QApplication.desktop().screenNumber(QApplication.desktop().cursor().pos())
        center_point = QApplication.desktop().screenGeometry(screen).center()
        frame_gm.moveCenter(center_point)
        self.move(frame_gm.topLeft())


        layout = QVBoxLayout()

        # Grupo de camadas
        self.label_group = QLabel("Selecione o GRUPO com as imagens:")
        layout.addWidget(self.label_group)        
        self.combo_group = QComboBox()
        # monta e exibe lista com Grupo de camadas
        self.groups = self.get_layer_groups()
        self.combo_group.addItems(self.groups)
        layout.addWidget(self.combo_group)

        # Diretório de saída local
        self.label_dir = QLabel("Diretório de Saída (local):")
        layout.addWidget(self.label_dir)

        # Cria Diretório de saída local PADRÃO para ser usado caso usuario não informe outro
        destination_folder = os.path.expanduser(r"~/Downloads/EXPORTADAS")
        os.makedirs(destination_folder, exist_ok=True)

        self.dir_edit = QLineEdit()
        self.dir_edit.setText(destination_folder)
        layout.addWidget(self.dir_edit)

        btn_select_folder = QPushButton("Alterar Diretório de Saída")
        btn_select_folder.clicked.connect(lambda: self.select_folder())
        layout.addWidget(btn_select_folder)

        # Checkbox: exportar apenas camadas selecionadas
        self.checkbox_selected = QCheckBox("Exportar apenas camadas selecionadas do Grupo !")
        self.checkbox_selected.setChecked(False)
        layout.addWidget(self.checkbox_selected)

        # Botões
        self.btn_export = QPushButton("Exportar e Gerar ZIP")
        self.btn_export.clicked.connect(self.export_layers)
        layout.addWidget(self.btn_export)

        # Mensagem de status
        self.status_label = QLabel("")
        layout.addWidget(self.status_label)

        # Log
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        layout.addWidget(self.log_output)

        self.setLayout(layout)

#-----------------------------FIM DA CRIAÇÂO DA INTERFACE -------------------------------------------------------------------





    # ---------- Algumas Funções utilizadas ----------
    #  """Exibe mensagens no campo de log da interface"""
    def log(self, message):
        self.log_output.append(message)
        QApplication.processEvents()  # garante atualização imediata das mensagens

    #""" Obtém os nomes de todos os grupos de camadas no projeto """
    def get_layer_groups(self):
        root = QgsProject.instance().layerTreeRoot()
        groups = [node.name() for node in root.children() if isinstance(node, QgsLayerTreeGroup)]
        if not groups:
            groups = ["<Nenhum grupo encontrado>"]
        return groups

    #""" Definir novo diretorio de saída caso deseje"""
    def select_folder(self):
        current_path = self.dir_edit.text() or os.path.expanduser("~")
        folder = QFileDialog.getExistingDirectory(self, "Selecionar Pasta de Destino", current_path)
        if folder:
            self.dir_edit.setText(folder)
            self.log(f"📁 Pasta de destino alterada para: {folder}")
            self.log("")

    #"""Retorna nomes das camadas marcadas dentro do grupo selecionado."""
    def get_selected_layer_names_from_treeroot(self, group):
        
        try:
            checked = []
            for child in group.children():
                if hasattr(child, "layer") and child.layer() is not None:
                    if child.isVisible():
                        checked.append(child.layer().name())
            return checked
        except Exception:
            return []

    # ---------- FUNÇÃO PRINCIPAL DE EXPORTAR  ----------
    def export_layers(self):
        group_name = self.combo_group.currentText()
        output_dir = self.dir_edit.text().strip()

        if not os.path.exists(output_dir):
            self.log(f"🔴 Diretório de saída '{output_dir}' não existe.")
            return

        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(group_name)
        if not group:
            self.log(f"🚫: Grupo '{group_name}' não encontrado.")
            return

        only_selected = self.checkbox_selected.isChecked()
        if only_selected:
            selected_names = self.get_selected_layer_names_from_treeroot(group)
            if not selected_names:
                self.log("⚠️ Não há camada selecionada no Grupo... Abortando.")
                return
            self.log(f"♻️ Exportando Imagens Selecionadas")
        else:
            selected_names = None


        self.log("")
        self.log("🔄 Processando...")

        exported_files = []

        for node in group.children():
            if isinstance(node, QgsLayerTreeGroup):
                continue

            qgis_layer = node.layer()
            if not qgis_layer or qgis_layer.type() != QgsMapLayer.RasterLayer:
                continue

            layer_name = qgis_layer.name()
            if only_selected and layer_name not in selected_names:
                continue

            safe_name = "".join(c if c.isalnum() or c in "-_." else "_" for c in layer_name)
            output_path = os.path.join(output_dir, f"{safe_name}_contraste.tif")

            try:
                # --- preparar writer e pipe ---
                provider = qgis_layer.dataProvider()
                file_writer = QgsRasterFileWriter(output_path)
                pipe = QgsRasterPipe()
                pipe.set(provider.clone())
                try:
                    renderer = qgis_layer.renderer()
                    pipe.set(renderer.clone())
                except Exception:
                    # se não for possível clonar renderer, apenas escrever os dados
                    pass

                success = file_writer.writeRaster(
                    pipe,
                    provider.xSize(),
                    provider.ySize(),
                    provider.extent(),
                    provider.crs()
                )

                if success == 0:
                    self.log(f"💾 Exportado: {os.path.basename(output_path)}")
                    # remover banda alpha (se existir)
                    try:
                        ds = gdal.Open(output_path, gdal.GA_ReadOnly)
                        if ds and ds.RasterCount == 4:
                            output_no_alpha = output_path.replace(".tif", "_noalpha.tif")
                            gdal.Translate(output_no_alpha, ds, format="GTiff", bandList=[1, 2, 3])
                            ds = None
                            os.remove(output_path)
                            os.rename(output_no_alpha, output_path)
                            self.log("   • Banda alpha removida")
                    except Exception as e:
                        self.log(f"   • Aviso: falha ao processar banda alpha: {e}")

                    exported_files.append(output_path)
                else:
                    self.log(f"❌ Erro ao exportar a camada: {layer_name}")
            except Exception as e:
                self.log(f"❌ Exceção exportando {layer_name}: {e}")
                self.log(traceback.format_exc())

        if not exported_files:
            self.log("⚠️ Nenhum arquivo foi exportado.")
            return

        # --- compactar cada arquivo em um zip individual ---
        zip_files = []

        for tif in exported_files:

            try:

                base, _ = os.path.splitext(tif)

                jpg_path = base + ".jpg"
                zip_path = base + ".zip"

                # gerar JPG preview
                gdal.Translate(
                    jpg_path,
                    tif,
                    format="JPEG",
                    creationOptions=["QUALITY=50"],
                    width=2000
                )

                # criar ZIP com tif + jpg
                with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                    zf.write(tif, os.path.basename(tif))
                    zf.write(jpg_path, os.path.basename(jpg_path))

                self.log(f"🗜️ Compactado: {os.path.basename(zip_path)}")

                zip_files.append(zip_path)

                # remover jpg temporário (opcional)
                if os.path.exists(jpg_path):
                    os.remove(jpg_path)

            except Exception as e:

                self.log(f"❌ Erro ao compactar {tif}: {e}")
                self.log(traceback.format_exc())


        # resumo
        self.log("")
        self.log(f"✅ Exportados: {len(exported_files)} TIFF(s).")
        self.log(f"✅ Compactados: {len(zip_files)} ZIP(s).")
        self.log("🎉 Processo concluído com sucesso!")

      
        
        
        # mensagem de navegador
        filebrowser_url = "https://terrabrasilis.dpi.inpe.br/filebrowser/files/BIOMAS_BR/CERRADO/IMAGENS/DETER/"
        self.log(f"\n🌐 ARQUIVOS ZIPS PRONTOS PARA ENVIAR AO SERVIDOR: \n{filebrowser_url}")
#-----------------------------------------------------------------------FIM---------------------------------------------------------------------


# Para executar no console do QGIS:
# dialog = ExportDialog()
# dialog.show()

# E COMENTAR TUDO ABAIXO !!!!!!!!!!!!




# ---------- PARTE ESPECIFICA PARA PLUGIN----------
class ExportPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon_estilo3.png")
        self.action = QAction(QIcon(icon_path), "Exportar Imagens DETER Cerrado", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("BIOMASBR_CERRADO", self.action)

    def unload(self):
        self.iface.removePluginMenu("BIOMASBR_CERRADO", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        dlg = ExportDialog()
        dlg.exec_()
        
        
        
        
